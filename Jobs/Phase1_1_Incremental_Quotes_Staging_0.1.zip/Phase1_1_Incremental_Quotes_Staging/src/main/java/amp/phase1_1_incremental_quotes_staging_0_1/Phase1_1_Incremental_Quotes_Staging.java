
package amp.phase1_1_incremental_quotes_staging_0_1;

import routines.DataOperation;
import routines.TalendDataGenerator;
import routines.DataQuality;
import routines.Relational;
import routines.Mathematical;
import routines.DataQualityDependencies;
import routines.SQLike;
import routines.Numeric;
import routines.TalendStringUtil;
import routines.TalendString;
import routines.StringHandling;
import routines.DQTechnical;
import routines.TalendDate;
import routines.DataMasking;
import routines.DqStringHandling;
import routines.system.*;
import routines.system.api.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;
 




	//the import part of tJava_2
	//import java.util.List;

	//the import part of tJava_1
	//import java.util.List;

	//the import part of tJava_4
	//import java.util.List;

	//the import part of tJava_5
	//import java.util.List;

	//the import part of tJava_6
	//import java.util.List;

	//the import part of tJava_3
	//import java.util.List;


@SuppressWarnings("unused")

/**
 * Job: Phase1_1_Incremental_Quotes_Staging Purpose: <br>
 * Description: Landing to Staging (including Merging) <br>
 * @author Joshi, Aayush
 * @version 7.2.1.20190909_1200_patch
 * @status 
 */
public class Phase1_1_Incremental_Quotes_Staging implements TalendJob {
	static {System.setProperty("TalendJob.log", "Phase1_1_Incremental_Quotes_Staging.log");}
	private static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Phase1_1_Incremental_Quotes_Staging.class);

protected static void logIgnoredError(String message, Throwable cause) {
       log.error(message, cause);

}


	public final Object obj = new Object();

	// for transmiting parameters purpose
	private Object valueObject = null;

	public Object getValueObject() {
		return this.valueObject;
	}

	public void setValueObject(Object valueObject) {
		this.valueObject = valueObject;
	}
	
	private final static String defaultCharset = java.nio.charset.Charset.defaultCharset().name();

	
	private final static String utf8Charset = "UTF-8";
	//contains type for every context property
	public class PropertiesWithType extends java.util.Properties {
		private static final long serialVersionUID = 1L;
		private java.util.Map<String,String> propertyTypes = new java.util.HashMap<>();
		
		public PropertiesWithType(java.util.Properties properties){
			super(properties);
		}
		public PropertiesWithType(){
			super();
		}
		
		public void setContextType(String key, String type) {
			propertyTypes.put(key,type);
		}
	
		public String getContextType(String key) {
			return propertyTypes.get(key);
		}
	}
	
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();
	// create application properties with default
	public class ContextProperties extends PropertiesWithType {

		private static final long serialVersionUID = 1L;

		public ContextProperties(java.util.Properties properties){
			super(properties);
		}
		public ContextProperties(){
			super();
		}

		public void synchronizeContext(){
			
			if(Database_DB_Landing != null){
				
					this.setProperty("Database_DB_Landing", Database_DB_Landing.toString());
				
			}
			
			if(Database_DB_Staging != null){
				
					this.setProperty("Database_DB_Staging", Database_DB_Staging.toString());
				
			}
			
			if(Discovery_Service_End_Point_CRM != null){
				
					this.setProperty("Discovery_Service_End_Point_CRM", Discovery_Service_End_Point_CRM.toString());
				
			}
			
			if(Host_DB_Landing != null){
				
					this.setProperty("Host_DB_Landing", Host_DB_Landing.toString());
				
			}
			
			if(Host_DB_Staging != null){
				
					this.setProperty("Host_DB_Staging", Host_DB_Staging.toString());
				
			}
			
			if(Mail_From != null){
				
					this.setProperty("Mail_From", Mail_From.toString());
				
			}
			
			if(Mail_To != null){
				
					this.setProperty("Mail_To", Mail_To.toString());
				
			}
			
			if(MergeStagingTable != null){
				
					this.setProperty("MergeStagingTable", MergeStagingTable.toString());
				
			}
			
			if(OrganizeName_CRM != null){
				
					this.setProperty("OrganizeName_CRM", OrganizeName_CRM.toString());
				
			}
			
			if(Password_CRM != null){
				
					this.setProperty("Password_CRM", Password_CRM.toString());
				
			}
			
			if(Password_DB_Landing != null){
				
					this.setProperty("Password_DB_Landing", Password_DB_Landing.toString());
				
			}
			
			if(Password_DB_Staging != null){
				
					this.setProperty("Password_DB_Staging", Password_DB_Staging.toString());
				
			}
			
			if(Port_DB_Landing != null){
				
					this.setProperty("Port_DB_Landing", Port_DB_Landing.toString());
				
			}
			
			if(Port_DB_Staging != null){
				
					this.setProperty("Port_DB_Staging", Port_DB_Staging.toString());
				
			}
			
			if(Schema_DB_Landing != null){
				
					this.setProperty("Schema_DB_Landing", Schema_DB_Landing.toString());
				
			}
			
			if(Schema_DB_Staging != null){
				
					this.setProperty("Schema_DB_Staging", Schema_DB_Staging.toString());
				
			}
			
			if(SIGMA_DB_Database != null){
				
					this.setProperty("SIGMA_DB_Database", SIGMA_DB_Database.toString());
				
			}
			
			if(SIGMA_DB_Host != null){
				
					this.setProperty("SIGMA_DB_Host", SIGMA_DB_Host.toString());
				
			}
			
			if(SIGMA_DB_Login != null){
				
					this.setProperty("SIGMA_DB_Login", SIGMA_DB_Login.toString());
				
			}
			
			if(SIGMA_DB_Password != null){
				
					this.setProperty("SIGMA_DB_Password", SIGMA_DB_Password.toString());
				
			}
			
			if(SIGMA_DB_Port != null){
				
					this.setProperty("SIGMA_DB_Port", SIGMA_DB_Port.toString());
				
			}
			
			if(SIGMA_DB_Schema != null){
				
					this.setProperty("SIGMA_DB_Schema", SIGMA_DB_Schema.toString());
				
			}
			
			if(SigmaTable_L != null){
				
					this.setProperty("SigmaTable_L", SigmaTable_L.toString());
				
			}
			
			if(SigmaTable_S != null){
				
					this.setProperty("SigmaTable_S", SigmaTable_S.toString());
				
			}
			
			if(SMTP_Host != null){
				
					this.setProperty("SMTP_Host", SMTP_Host.toString());
				
			}
			
			if(SMTP_Port != null){
				
					this.setProperty("SMTP_Port", SMTP_Port.toString());
				
			}
			
			if(TOM_DB_Database != null){
				
					this.setProperty("TOM_DB_Database", TOM_DB_Database.toString());
				
			}
			
			if(TOM_DB_Host != null){
				
					this.setProperty("TOM_DB_Host", TOM_DB_Host.toString());
				
			}
			
			if(TOM_DB_Login != null){
				
					this.setProperty("TOM_DB_Login", TOM_DB_Login.toString());
				
			}
			
			if(TOM_DB_Password != null){
				
					this.setProperty("TOM_DB_Password", TOM_DB_Password.toString());
				
			}
			
			if(TOM_DB_Port != null){
				
					this.setProperty("TOM_DB_Port", TOM_DB_Port.toString());
				
			}
			
			if(TOM_DB_Schema != null){
				
					this.setProperty("TOM_DB_Schema", TOM_DB_Schema.toString());
				
			}
			
			if(TomTable_L != null){
				
					this.setProperty("TomTable_L", TomTable_L.toString());
				
			}
			
			if(TomTable_S != null){
				
					this.setProperty("TomTable_S", TomTable_S.toString());
				
			}
			
			if(Username_CRM != null){
				
					this.setProperty("Username_CRM", Username_CRM.toString());
				
			}
			
			if(Username_DB_Landing != null){
				
					this.setProperty("Username_DB_Landing", Username_DB_Landing.toString());
				
			}
			
			if(Username_DB_Staging != null){
				
					this.setProperty("Username_DB_Staging", Username_DB_Staging.toString());
				
			}
			
		}

public String Database_DB_Landing;
public String getDatabase_DB_Landing(){
	return this.Database_DB_Landing;
}
public String Database_DB_Staging;
public String getDatabase_DB_Staging(){
	return this.Database_DB_Staging;
}
public String Discovery_Service_End_Point_CRM;
public String getDiscovery_Service_End_Point_CRM(){
	return this.Discovery_Service_End_Point_CRM;
}
public String Host_DB_Landing;
public String getHost_DB_Landing(){
	return this.Host_DB_Landing;
}
public String Host_DB_Staging;
public String getHost_DB_Staging(){
	return this.Host_DB_Staging;
}
public String Mail_From;
public String getMail_From(){
	return this.Mail_From;
}
public String Mail_To;
public String getMail_To(){
	return this.Mail_To;
}
public String MergeStagingTable;
public String getMergeStagingTable(){
	return this.MergeStagingTable;
}
public String OrganizeName_CRM;
public String getOrganizeName_CRM(){
	return this.OrganizeName_CRM;
}
public java.lang.String Password_CRM;
public java.lang.String getPassword_CRM(){
	return this.Password_CRM;
}
public java.lang.String Password_DB_Landing;
public java.lang.String getPassword_DB_Landing(){
	return this.Password_DB_Landing;
}
public java.lang.String Password_DB_Staging;
public java.lang.String getPassword_DB_Staging(){
	return this.Password_DB_Staging;
}
public String Port_DB_Landing;
public String getPort_DB_Landing(){
	return this.Port_DB_Landing;
}
public String Port_DB_Staging;
public String getPort_DB_Staging(){
	return this.Port_DB_Staging;
}
public String Schema_DB_Landing;
public String getSchema_DB_Landing(){
	return this.Schema_DB_Landing;
}
public String Schema_DB_Staging;
public String getSchema_DB_Staging(){
	return this.Schema_DB_Staging;
}
public String SIGMA_DB_Database;
public String getSIGMA_DB_Database(){
	return this.SIGMA_DB_Database;
}
public String SIGMA_DB_Host;
public String getSIGMA_DB_Host(){
	return this.SIGMA_DB_Host;
}
public String SIGMA_DB_Login;
public String getSIGMA_DB_Login(){
	return this.SIGMA_DB_Login;
}
public java.lang.String SIGMA_DB_Password;
public java.lang.String getSIGMA_DB_Password(){
	return this.SIGMA_DB_Password;
}
public String SIGMA_DB_Port;
public String getSIGMA_DB_Port(){
	return this.SIGMA_DB_Port;
}
public String SIGMA_DB_Schema;
public String getSIGMA_DB_Schema(){
	return this.SIGMA_DB_Schema;
}
public String SigmaTable_L;
public String getSigmaTable_L(){
	return this.SigmaTable_L;
}
public String SigmaTable_S;
public String getSigmaTable_S(){
	return this.SigmaTable_S;
}
public String SMTP_Host;
public String getSMTP_Host(){
	return this.SMTP_Host;
}
public String SMTP_Port;
public String getSMTP_Port(){
	return this.SMTP_Port;
}
public String TOM_DB_Database;
public String getTOM_DB_Database(){
	return this.TOM_DB_Database;
}
public String TOM_DB_Host;
public String getTOM_DB_Host(){
	return this.TOM_DB_Host;
}
public String TOM_DB_Login;
public String getTOM_DB_Login(){
	return this.TOM_DB_Login;
}
public java.lang.String TOM_DB_Password;
public java.lang.String getTOM_DB_Password(){
	return this.TOM_DB_Password;
}
public String TOM_DB_Port;
public String getTOM_DB_Port(){
	return this.TOM_DB_Port;
}
public String TOM_DB_Schema;
public String getTOM_DB_Schema(){
	return this.TOM_DB_Schema;
}
public String TomTable_L;
public String getTomTable_L(){
	return this.TomTable_L;
}
public String TomTable_S;
public String getTomTable_S(){
	return this.TomTable_S;
}
public String Username_CRM;
public String getUsername_CRM(){
	return this.Username_CRM;
}
public String Username_DB_Landing;
public String getUsername_DB_Landing(){
	return this.Username_DB_Landing;
}
public String Username_DB_Staging;
public String getUsername_DB_Staging(){
	return this.Username_DB_Staging;
}
	}
	protected ContextProperties context = new ContextProperties(); // will be instanciated by MS.
	public ContextProperties getContext() {
		return this.context;
	}
	private final String jobVersion = "0.1";
	private final String jobName = "Phase1_1_Incremental_Quotes_Staging";
	private final String projectName = "AMP";
	public Integer errorCode = null;
	private String currentComponent = "";
	
		private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
        private final static java.util.Map<String, Object> junitGlobalMap = new java.util.HashMap<String, Object>();
	
		private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
		private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
		public  final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();
	

private RunStat runStat = new RunStat();

	// OSGi DataSource
	private final static String KEY_DB_DATASOURCES = "KEY_DB_DATASOURCES";
	
	private final static String KEY_DB_DATASOURCES_RAW = "KEY_DB_DATASOURCES_RAW";

	public void setDataSources(java.util.Map<String, javax.sql.DataSource> dataSources) {
		java.util.Map<String, routines.system.TalendDataSource> talendDataSources = new java.util.HashMap<String, routines.system.TalendDataSource>();
		for (java.util.Map.Entry<String, javax.sql.DataSource> dataSourceEntry : dataSources.entrySet()) {
			talendDataSources.put(dataSourceEntry.getKey(), new routines.system.TalendDataSource(dataSourceEntry.getValue()));
		}
		globalMap.put(KEY_DB_DATASOURCES, talendDataSources);
		globalMap.put(KEY_DB_DATASOURCES_RAW, new java.util.HashMap<String, javax.sql.DataSource>(dataSources));
	}

	LogCatcherUtils tLogCatcher_1 = new LogCatcherUtils();
	JobStructureCatcherUtils talendJobLog = new JobStructureCatcherUtils(jobName, "_C3iXsF1UEeq68ftYgXJEJQ", "0.1");
	org.talend.job.audit.JobAuditLogger auditLogger_talendJobLog = null;
	AssertCatcherUtils tAssertCatcher_1 = new AssertCatcherUtils();

private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(new java.io.BufferedOutputStream(baos));

public String getExceptionStackTrace() {
	if ("failure".equals(this.getStatus())) {
		errorMessagePS.flush();
		return baos.toString();
	}
	return null;
}

private Exception exception;

public Exception getException() {
	if ("failure".equals(this.getStatus())) {
		return this.exception;
	}
	return null;
}

private class TalendException extends Exception {

	private static final long serialVersionUID = 1L;

	private java.util.Map<String, Object> globalMap = null;
	private Exception e = null;
	private String currentComponent = null;
	private String virtualComponentName = null;
	
	public void setVirtualComponentName (String virtualComponentName){
		this.virtualComponentName = virtualComponentName;
	}

	private TalendException(Exception e, String errorComponent, final java.util.Map<String, Object> globalMap) {
		this.currentComponent= errorComponent;
		this.globalMap = globalMap;
		this.e = e;
	}

	public Exception getException() {
		return this.e;
	}

	public String getCurrentComponent() {
		return this.currentComponent;
	}

	
    public String getExceptionCauseMessage(Exception e){
        Throwable cause = e;
        String message = null;
        int i = 10;
        while (null != cause && 0 < i--) {
            message = cause.getMessage();
            if (null == message) {
                cause = cause.getCause();
            } else {
                break;          
            }
        }
        if (null == message) {
            message = e.getClass().getName();
        }   
        return message;
    }

	@Override
	public void printStackTrace() {
		if (!(e instanceof TalendException || e instanceof TDieException)) {
			if(virtualComponentName!=null && currentComponent.indexOf(virtualComponentName+"_")==0){
				globalMap.put(virtualComponentName+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			}
			globalMap.put(currentComponent+"_ERROR_MESSAGE",getExceptionCauseMessage(e));
			System.err.println("Exception in component " + currentComponent + " (" + jobName + ")");
		}
		if (!(e instanceof TDieException)) {
			if(e instanceof TalendException){
				e.printStackTrace();
			} else {
				e.printStackTrace();
				e.printStackTrace(errorMessagePS);
				Phase1_1_Incremental_Quotes_Staging.this.exception = e;
			}
		}
		if (!(e instanceof TalendException)) {
		try {
			for (java.lang.reflect.Method m : this.getClass().getEnclosingClass().getMethods()) {
				if (m.getName().compareTo(currentComponent + "_error") == 0) {
					m.invoke(Phase1_1_Incremental_Quotes_Staging.this, new Object[] { e , currentComponent, globalMap});
					break;
				}
			}

			if(!(e instanceof TDieException)){
				tLogCatcher_1.addMessage("Java Exception", currentComponent, 6, e.getClass().getName() + ":" + e.getMessage(), 1);
				tLogCatcher_1Process(globalMap);
			}
			} catch (TalendException e) {
				// do nothing
			
		} catch (Exception e) {
			this.e.printStackTrace();
		}
		}
	}
}

			public void tPrejob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tPrejob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tFileInputExcel_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tMap_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tContextLoad_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tFileInputExcel_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tAssertCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tAssertCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogCatcher_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tLogRow_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tLogCatcher_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tSendMail_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tDBConnection_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tDBConnection_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tDBConnection_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tDBConnection_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tDBConnection_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tRunJob_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tRunJob_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_5_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_5_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tRunJob_4_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tRunJob_4_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_6_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_6_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPostjob_1_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tPostjob_1_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tJava_3_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tJava_3_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tSendMail_2_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					tSendMail_2_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void talendJobLog_error(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {
				
				end_Hash.put(errorComponent, System.currentTimeMillis());
				
								if(!(exception instanceof TDieException)){
									
										tAssertCatcher_1.addMessage(pid, projectName, jobName, "java", null, "Failed", "Job execution error", exception);
									
									tAssertCatcher_1Process(globalMap);
								}
								
				status = "failure";
				
					talendJobLog_onSubJobError(exception, errorComponent, globalMap);
			}
			
			public void tPrejob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tFileInputExcel_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tAssertCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tLogCatcher_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tDBConnection_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_5_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tRunJob_4_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_6_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tPostjob_1_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tJava_3_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void tSendMail_2_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
			public void talendJobLog_onSubJobError(Exception exception, String errorComponent, final java.util.Map<String, Object> globalMap) throws TalendException {

resumeUtil.addLog("SYSTEM_LOG", "NODE:"+ errorComponent, "", Thread.currentThread().getId()+ "", "FATAL", "", exception.getMessage(), ResumeUtil.getExceptionStackTrace(exception),"");

			}
	

	





public void tPrejob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPrejob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPrejob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPrejob_1", false);
		start_Hash.put("tPrejob_1", System.currentTimeMillis());
		
	
	currentComponent="tPrejob_1";

	
		int tos_count_tPrejob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tPrejob_1", "tPrejob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPrejob_1 begin ] stop
 */
	
	/**
	 * [tPrejob_1 main ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 


	tos_count_tPrejob_1++;

/**
 * [tPrejob_1 main ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPrejob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 process_data_end ] stop
 */
	
	/**
	 * [tPrejob_1 end ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 

ok_Hash.put("tPrejob_1", true);
end_Hash.put("tPrejob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk1", 0, "ok");
				}
				tFileInputExcel_1Process(globalMap);



/**
 * [tPrejob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPrejob_1 finally ] start
	 */

	

	
	
	currentComponent="tPrejob_1";

	

 



/**
 * [tPrejob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPrejob_1_SUBPROCESS_STATE", 1);
	}
	


public static class copyOfcopyOfLoadStruct implements routines.system.IPersistableRow<copyOfcopyOfLoadStruct> {
    final static byte[] commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];
    static byte[] commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];

	
			    public String key;

				public String getKey () {
					return this.key;
				}
				
			    public String value;

				public String getValue () {
					return this.value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length) {
				if(length < 1024 && commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length == 0) {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[1024];
				} else {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length);
			strReturn = new String(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging) {

        	try {

        		int length = 0;
		
					this.key = readString(dis);
					
					this.value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.key,dos);
					
					// String
				
						writeString(this.value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("key="+key);
		sb.append(",value="+value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(key == null){
        					sb.append("<null>");
        				}else{
            				sb.append(key);
            			}
            		
        			sb.append("|");
        		
        				if(value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(copyOfcopyOfLoadStruct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}

public static class row106Struct implements routines.system.IPersistableRow<row106Struct> {
    final static byte[] commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];
    static byte[] commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];

	
			    public String Context_Variable_Name;

				public String getContext_Variable_Name () {
					return this.Context_Variable_Name;
				}
				
			    public String Value;

				public String getValue () {
					return this.Value;
				}
				



	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length) {
				if(length < 1024 && commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length == 0) {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[1024];
				} else {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length);
			strReturn = new String(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging) {

        	try {

        		int length = 0;
		
					this.Context_Variable_Name = readString(dis);
					
					this.Value = readString(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// String
				
						writeString(this.Context_Variable_Name,dos);
					
					// String
				
						writeString(this.Value,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("Context_Variable_Name="+Context_Variable_Name);
		sb.append(",Value="+Value);
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(Context_Variable_Name == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Context_Variable_Name);
            			}
            		
        			sb.append("|");
        		
        				if(Value == null){
        					sb.append("<null>");
        				}else{
            				sb.append(Value);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row106Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tFileInputExcel_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row106Struct row106 = new row106Struct();
copyOfcopyOfLoadStruct copyOfcopyOfLoad = new copyOfcopyOfLoadStruct();





	
	/**
	 * [tContextLoad_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tContextLoad_1", false);
		start_Hash.put("tContextLoad_1", System.currentTimeMillis());
		
	
	currentComponent="tContextLoad_1";

	
			if (execStat || enableLogStash) {
				if(resourceMap.get("inIterateVComp") == null){
					
						
						if(execStat) {
							runStat.updateStatOnConnection("copyOfcopyOfLoad"+iterateId, 0, 0);
						}
						
						
						
						if(enableLogStash) {
							runStat.logStatOnConnection("copyOfcopyOfLoad"+iterateId, 0, 0);
						}
						
					
				}
			} 

		
		int tos_count_tContextLoad_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tContextLoad_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tContextLoad_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tContextLoad_1 = new StringBuilder();
                    log4jParamters_tContextLoad_1.append("Parameters:");
                            log4jParamters_tContextLoad_1.append("LOAD_NEW_VARIABLE" + " = " + "Warning");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("NOT_LOAD_OLD_VARIABLE" + " = " + "Warning");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("PRINT_OPERATIONS" + " = " + "false");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("DISABLE_ERROR" + " = " + "false");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("DISABLE_WARNINGS" + " = " + "true");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("DISABLE_INFO" + " = " + "true");
                        log4jParamters_tContextLoad_1.append(" | ");
                            log4jParamters_tContextLoad_1.append("DIEONERROR" + " = " + "true");
                        log4jParamters_tContextLoad_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tContextLoad_1 - "  + (log4jParamters_tContextLoad_1) );
                    } 
                } 
            new BytesLimit65535_tContextLoad_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tContextLoad_1", "tContextLoad");
				talendJobLogProcess(globalMap);
			}
			
	java.util.List<String> assignList_tContextLoad_1 = new java.util.ArrayList<String>();
	java.util.List<String> newPropertyList_tContextLoad_1 = new java.util.ArrayList<String>();
	java.util.List<String> noAssignList_tContextLoad_1 = new java.util.ArrayList<String>();
	int nb_line_tContextLoad_1 = 0;

 



/**
 * [tContextLoad_1 begin ] stop
 */



	
	/**
	 * [tMap_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tMap_1", false);
		start_Hash.put("tMap_1", System.currentTimeMillis());
		
	
	currentComponent="tMap_1";

	
			if (execStat || enableLogStash) {
				if(resourceMap.get("inIterateVComp") == null){
					
						
						if(execStat) {
							runStat.updateStatOnConnection("row106"+iterateId, 0, 0);
						}
						
						
						
						if(enableLogStash) {
							runStat.logStatOnConnection("row106"+iterateId, 0, 0);
						}
						
					
				}
			} 

		
		int tos_count_tMap_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tMap_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tMap_1 = new StringBuilder();
                    log4jParamters_tMap_1.append("Parameters:");
                            log4jParamters_tMap_1.append("LINK_STYLE" + " = " + "AUTO");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("TEMPORARY_DATA_DIRECTORY" + " = " + "");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("ROWS_BUFFER_SIZE" + " = " + "2000000");
                        log4jParamters_tMap_1.append(" | ");
                            log4jParamters_tMap_1.append("CHANGE_HASH_AND_EQUALS_FOR_BIGDECIMAL" + " = " + "false");
                        log4jParamters_tMap_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + (log4jParamters_tMap_1) );
                    } 
                } 
            new BytesLimit65535_tMap_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tMap_1", "tMap");
				talendJobLogProcess(globalMap);
			}
			




// ###############################
// # Lookup's keys initialization
		int count_row106_tMap_1 = 0;
		
// ###############################        

// ###############################
// # Vars initialization
class  Var__tMap_1__Struct  {
}
Var__tMap_1__Struct Var__tMap_1 = new Var__tMap_1__Struct();
// ###############################

// ###############################
// # Outputs initialization
				int count_copyOfcopyOfLoad_tMap_1 = 0;
				
copyOfcopyOfLoadStruct copyOfcopyOfLoad_tmp = new copyOfcopyOfLoadStruct();
// ###############################

        
        



        









 



/**
 * [tMap_1 begin ] stop
 */



	
	/**
	 * [tFileInputExcel_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tFileInputExcel_1", false);
		start_Hash.put("tFileInputExcel_1", System.currentTimeMillis());
		
	
	currentComponent="tFileInputExcel_1";

	
		int tos_count_tFileInputExcel_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tFileInputExcel_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tFileInputExcel_1 = new StringBuilder();
                    log4jParamters_tFileInputExcel_1.append("Parameters:");
                            log4jParamters_tFileInputExcel_1.append("VERSION_2007" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FILENAME" + " = " + "\"C:/Talend_CRM/AMP/Incremental/Context_Talend_CRM.xls\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ALL_SHEETS" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("HEADER" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FOOTER" + " = " + "0");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LIMIT" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("AFFECT_EACH_SHEET" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("FIRST_COLUMN" + " = " + "1");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("LAST_COLUMN" + " = " + "");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ADVANCED_SEPARATOR" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMALL" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("TRIMSELECT" + " = " + "[{TRIM="+("false")+", SCHEMA_COLUMN="+("Context_Variable_Name")+"}, {TRIM="+("false")+", SCHEMA_COLUMN="+("Value")+"}]");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("ENCODING" + " = " + "\"UTF-8\"");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("READ_REAL_VALUE" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("STOPREAD_ON_EMPTYROW" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("NOVALIDATE_ON_CELL" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                            log4jParamters_tFileInputExcel_1.append("SUPPRESS_WARN" + " = " + "false");
                        log4jParamters_tFileInputExcel_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + (log4jParamters_tFileInputExcel_1) );
                    } 
                } 
            new BytesLimit65535_tFileInputExcel_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tFileInputExcel_1", "tFileInputExcel");
				talendJobLogProcess(globalMap);
			}
			



			class RegexUtil_tFileInputExcel_1 {

		    	public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, String oneSheetName, boolean useRegex) {

			        java.util.List<jxl.Sheet> list = new java.util.ArrayList<jxl.Sheet>();

			        if(useRegex){//this part process the regex issue

				        jxl.Sheet[] sheets = workbook.getSheets();
				        java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(oneSheetName);
				        for (int i = 0; i < sheets.length; i++) {
				            String sheetName = sheets[i].getName();
				            java.util.regex.Matcher matcher = pattern.matcher(sheetName);
				            if (matcher.matches()) {
				            	jxl.Sheet sheet = workbook.getSheet(sheetName);
				            	if(sheet != null){
				                	list.add(sheet);
				                }
				            }
				        }

			        }else{
			        	jxl.Sheet sheet = workbook.getSheet(oneSheetName);
		            	if(sheet != null){
		                	list.add(sheet);
		                }

			        }

			        return list;
			    }

			    public java.util.List<jxl.Sheet> getSheets(jxl.Workbook workbook, int index, boolean useRegex) {
			    	java.util.List<jxl.Sheet> list =  new java.util.ArrayList<jxl.Sheet>();
			    	jxl.Sheet sheet = workbook.getSheet(index);
	            	if(sheet != null){
	                	list.add(sheet);
	                }
			    	return list;
			    }

			}


		RegexUtil_tFileInputExcel_1 regexUtil_tFileInputExcel_1 = new RegexUtil_tFileInputExcel_1();
		final jxl.WorkbookSettings workbookSettings_tFileInputExcel_1 = new jxl.WorkbookSettings();
		workbookSettings_tFileInputExcel_1.setDrawingsDisabled(true);
        workbookSettings_tFileInputExcel_1.setEncoding("UTF-8");

        Object source_tFileInputExcel_1 ="C:/Talend_CRM/AMP/Incremental/Context_Talend_CRM.xls";
        final jxl.Workbook workbook_tFileInputExcel_1;

        java.io.InputStream toClose_tFileInputExcel_1 = null;
        java.io.BufferedInputStream buffIStreamtFileInputExcel_1 = null;
        try {
            if(source_tFileInputExcel_1 instanceof java.io.InputStream){
        		toClose_tFileInputExcel_1 = (java.io.InputStream)source_tFileInputExcel_1;
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else if(source_tFileInputExcel_1 instanceof String){
        		toClose_tFileInputExcel_1 = new java.io.FileInputStream(source_tFileInputExcel_1.toString());
        		buffIStreamtFileInputExcel_1 = new java.io.BufferedInputStream(toClose_tFileInputExcel_1);
        		workbook_tFileInputExcel_1 = jxl.Workbook.getWorkbook(buffIStreamtFileInputExcel_1, workbookSettings_tFileInputExcel_1);
            }else{
            	workbook_tFileInputExcel_1 = null;
            	throw new java.lang.Exception("The data source should be specified as Inputstream or File Path!");
            }
        } finally {
			try{
			   if(buffIStreamtFileInputExcel_1 != null){
			   	  buffIStreamtFileInputExcel_1.close();
			   }
			}catch(Exception e){
			}
        }
        try {
		java.util.List<jxl.Sheet> sheetList_tFileInputExcel_1 = java.util.Arrays.<jxl.Sheet> asList(workbook_tFileInputExcel_1.getSheets());
        if(sheetList_tFileInputExcel_1.size() <= 0){
        	throw new RuntimeException("Special sheets not exist!");
        }

        java.util.List<jxl.Sheet> sheet_FilterNullList_tFileInputExcel_1 = new java.util.ArrayList<jxl.Sheet>();
        for(jxl.Sheet sheet_FilterNull_tFileInputExcel_1 : sheetList_tFileInputExcel_1){
        	if(sheet_FilterNull_tFileInputExcel_1.getRows()>0){
        		sheet_FilterNullList_tFileInputExcel_1.add(sheet_FilterNull_tFileInputExcel_1);
        	}
        }
		sheetList_tFileInputExcel_1 = sheet_FilterNullList_tFileInputExcel_1;
	if(sheetList_tFileInputExcel_1.size()>0){
        int nb_line_tFileInputExcel_1 = 0;

        int begin_line_tFileInputExcel_1 = 1;

        int footer_input_tFileInputExcel_1 = 0;

        int end_line_tFileInputExcel_1=0;
        for(jxl.Sheet sheet_tFileInputExcel_1:sheetList_tFileInputExcel_1){
        	end_line_tFileInputExcel_1+=sheet_tFileInputExcel_1.getRows();
        }
        end_line_tFileInputExcel_1 -= footer_input_tFileInputExcel_1;
        int limit_tFileInputExcel_1 = -1;
        int start_column_tFileInputExcel_1 = 1-1;
        int end_column_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getColumns();
        jxl.Cell[] row_tFileInputExcel_1 = null;
        jxl.Sheet sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0);
        int rowCount_tFileInputExcel_1 = 0;
        int sheetIndex_tFileInputExcel_1 = 0;
        int currentRows_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(0).getRows();

        //for the number format
        java.text.DecimalFormat df_tFileInputExcel_1 = new java.text.DecimalFormat("#.####################################");
		char separatorChar_tFileInputExcel_1 = df_tFileInputExcel_1.getDecimalFormatSymbols().getDecimalSeparator();
		
						log.debug("tFileInputExcel_1 - Retrieving records from the datasource.");
			
		
        for(int i_tFileInputExcel_1 = begin_line_tFileInputExcel_1; i_tFileInputExcel_1 < end_line_tFileInputExcel_1; i_tFileInputExcel_1++){

        	int emptyColumnCount_tFileInputExcel_1 = 0;

        	if (limit_tFileInputExcel_1 != -1 && nb_line_tFileInputExcel_1 >= limit_tFileInputExcel_1) {
        		break;
        	}

            while (i_tFileInputExcel_1 >= rowCount_tFileInputExcel_1 + currentRows_tFileInputExcel_1) {
                rowCount_tFileInputExcel_1 += currentRows_tFileInputExcel_1;
                sheet_tFileInputExcel_1 = sheetList_tFileInputExcel_1.get(++sheetIndex_tFileInputExcel_1);
                currentRows_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRows();
            }
            if (rowCount_tFileInputExcel_1 <= i_tFileInputExcel_1) {
                row_tFileInputExcel_1 = sheet_tFileInputExcel_1.getRow(i_tFileInputExcel_1 - rowCount_tFileInputExcel_1);
            }
        	globalMap.put("tFileInputExcel_1_CURRENT_SHEET",sheet_tFileInputExcel_1.getName());
    		row106 = null;
					int tempRowLength_tFileInputExcel_1 = 2;
				
				int columnIndex_tFileInputExcel_1 = 0;
			
//
//end%>
			
			String[] temp_row_tFileInputExcel_1 = new String[tempRowLength_tFileInputExcel_1];
			int actual_end_column_tFileInputExcel_1 = end_column_tFileInputExcel_1 >	row_tFileInputExcel_1.length ? row_tFileInputExcel_1.length : end_column_tFileInputExcel_1;

				java.util.TimeZone zone_tFileInputExcel_1 = java.util.TimeZone.getTimeZone("GMT");
                java.text.SimpleDateFormat sdf_tFileInputExcel_1 = new java.text.SimpleDateFormat("dd-MM-yyyy");
                sdf_tFileInputExcel_1.setTimeZone(zone_tFileInputExcel_1);
                

			for(int i=0;i<tempRowLength_tFileInputExcel_1;i++){

				if(i + start_column_tFileInputExcel_1 < actual_end_column_tFileInputExcel_1){

				  jxl.Cell cell_tFileInputExcel_1 = row_tFileInputExcel_1[i + start_column_tFileInputExcel_1];
                        temp_row_tFileInputExcel_1[i] = cell_tFileInputExcel_1.getContents();

				}else{
					temp_row_tFileInputExcel_1[i]="";
				}
			}

			boolean whetherReject_tFileInputExcel_1 = false;
			row106 = new row106Struct();
			int curColNum_tFileInputExcel_1 = -1;
			String curColName_tFileInputExcel_1 = "";
			try {
							columnIndex_tFileInputExcel_1 = 0;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Context_Variable_Name";
			row106.Context_Variable_Name = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row106.Context_Variable_Name = null;
				emptyColumnCount_tFileInputExcel_1++;
		}
							columnIndex_tFileInputExcel_1 = 1;
						
			if( temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1].length() > 0) {
				curColNum_tFileInputExcel_1=columnIndex_tFileInputExcel_1 + start_column_tFileInputExcel_1 + 1;
				curColName_tFileInputExcel_1 = "Value";
			row106.Value = temp_row_tFileInputExcel_1[columnIndex_tFileInputExcel_1];
			}else {
				row106.Value = null;
				emptyColumnCount_tFileInputExcel_1++;
		}

			nb_line_tFileInputExcel_1++;
			
				log.debug("tFileInputExcel_1 - Retrieving the record " + (nb_line_tFileInputExcel_1) + ".");
			
    } catch (java.lang.Exception e) {
        whetherReject_tFileInputExcel_1 = true;
            throw(e);
    }

					
		



 



/**
 * [tFileInputExcel_1 begin ] stop
 */
	
	/**
	 * [tFileInputExcel_1 main ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 


	tos_count_tFileInputExcel_1++;

/**
 * [tFileInputExcel_1 main ] stop
 */
	
	/**
	 * [tFileInputExcel_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_begin ] stop
 */
// Start of branch "row106"
if(row106 != null) { 



	
	/**
	 * [tMap_1 main ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

			//row106
			//row106


			
				
				if(execStat){
					runStat.updateStatOnConnection("row106"+iterateId,1, 1);
				}
				
				
				
				if(enableLogStash) {
					runStat.logStatOnConnection("row106"+iterateId,1, 1);
				}
				
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row106 - " + (row106==null? "": row106.toLogString()));
    			}
    		

		
		
		boolean hasCasePrimitiveKeyWithNull_tMap_1 = false;
		
        // ###############################
        // # Input tables (lookups)
		  boolean rejectedInnerJoin_tMap_1 = false;
		  boolean mainRowRejected_tMap_1 = false;
            				    								  
		// ###############################
        { // start of Var scope
        
	        // ###############################
        	// # Vars tables
        
Var__tMap_1__Struct Var = Var__tMap_1;// ###############################
        // ###############################
        // # Output tables

copyOfcopyOfLoad = null;


// # Output table : 'copyOfcopyOfLoad'
// # Filter conditions 
if( 

Relational.ISNULL(row106.Value)==false

 ) {
count_copyOfcopyOfLoad_tMap_1++;

copyOfcopyOfLoad_tmp.key = row106.Context_Variable_Name ;
copyOfcopyOfLoad_tmp.value = row106.Value ;
copyOfcopyOfLoad = copyOfcopyOfLoad_tmp;
log.debug("tMap_1 - Outputting the record " + count_copyOfcopyOfLoad_tMap_1 + " of the output table 'copyOfcopyOfLoad'.");

} // closing filter/reject
// ###############################

} // end of Var scope

rejectedInnerJoin_tMap_1 = false;










 


	tos_count_tMap_1++;

/**
 * [tMap_1 main ] stop
 */
	
	/**
	 * [tMap_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_begin ] stop
 */
// Start of branch "copyOfcopyOfLoad"
if(copyOfcopyOfLoad != null) { 



	
	/**
	 * [tContextLoad_1 main ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

			//copyOfcopyOfLoad
			//copyOfcopyOfLoad


			
				
				if(execStat){
					runStat.updateStatOnConnection("copyOfcopyOfLoad"+iterateId,1, 1);
				}
				
				
				
				if(enableLogStash) {
					runStat.logStatOnConnection("copyOfcopyOfLoad"+iterateId,1, 1);
				}
				
			

		
    			if(log.isTraceEnabled()){
    				log.trace("copyOfcopyOfLoad - " + (copyOfcopyOfLoad==null? "": copyOfcopyOfLoad.toLogString()));
    			}
    		
        //////////////////////////
        String tmp_key_tContextLoad_1 = null;
                    String key_tContextLoad_1 = null;
                      if (copyOfcopyOfLoad.key != null){
                          tmp_key_tContextLoad_1 = copyOfcopyOfLoad.key.trim();
                        if ((tmp_key_tContextLoad_1.startsWith("#") || tmp_key_tContextLoad_1.startsWith("!") )){
                          tmp_key_tContextLoad_1 = null;
                        } else {
                          copyOfcopyOfLoad.key = tmp_key_tContextLoad_1;
                        }
                      }
                        if(copyOfcopyOfLoad.key != null) {
                    key_tContextLoad_1 =
                        copyOfcopyOfLoad.key;
                        }
                    String value_tContextLoad_1 = null;
                        if(copyOfcopyOfLoad.value != null) {
                    value_tContextLoad_1 =
                        copyOfcopyOfLoad.value;
                        }
				
				String currentValue_tContextLoad_1 = value_tContextLoad_1;
										
						if ((key_tContextLoad_1 != null) && ("Password_CRM".equals(key_tContextLoad_1)) ) currentValue_tContextLoad_1 = currentValue_tContextLoad_1.replaceAll(".", "*");						
						if ((key_tContextLoad_1 != null) && ("Password_DB_Landing".equals(key_tContextLoad_1)) ) currentValue_tContextLoad_1 = currentValue_tContextLoad_1.replaceAll(".", "*");						
						if ((key_tContextLoad_1 != null) && ("Password_DB_Staging".equals(key_tContextLoad_1)) ) currentValue_tContextLoad_1 = currentValue_tContextLoad_1.replaceAll(".", "*");						
						if ((key_tContextLoad_1 != null) && ("SIGMA_DB_Password".equals(key_tContextLoad_1)) ) currentValue_tContextLoad_1 = currentValue_tContextLoad_1.replaceAll(".", "*");						
						if ((key_tContextLoad_1 != null) && ("TOM_DB_Password".equals(key_tContextLoad_1)) ) currentValue_tContextLoad_1 = currentValue_tContextLoad_1.replaceAll(".", "*");

  if (tmp_key_tContextLoad_1 != null){
  try{
        if(key_tContextLoad_1!=null && "Database_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Database_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Database_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Database_DB_Staging=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Discovery_Service_End_Point_CRM".equals(key_tContextLoad_1))
        {
           context.Discovery_Service_End_Point_CRM=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Host_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Host_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Host_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Host_DB_Staging=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Mail_From".equals(key_tContextLoad_1))
        {
           context.Mail_From=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Mail_To".equals(key_tContextLoad_1))
        {
           context.Mail_To=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "MergeStagingTable".equals(key_tContextLoad_1))
        {
           context.MergeStagingTable=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "OrganizeName_CRM".equals(key_tContextLoad_1))
        {
           context.OrganizeName_CRM=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Password_CRM".equals(key_tContextLoad_1))
        {
           context.Password_CRM=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Password_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Password_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Password_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Password_DB_Staging=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Port_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Port_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Port_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Port_DB_Staging=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Schema_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Schema_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Schema_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Schema_DB_Staging=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Database".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Database=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Host".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Host=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Login".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Login=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Password".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Password=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Port".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Port=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SIGMA_DB_Schema".equals(key_tContextLoad_1))
        {
           context.SIGMA_DB_Schema=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SigmaTable_L".equals(key_tContextLoad_1))
        {
           context.SigmaTable_L=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SigmaTable_S".equals(key_tContextLoad_1))
        {
           context.SigmaTable_S=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SMTP_Host".equals(key_tContextLoad_1))
        {
           context.SMTP_Host=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "SMTP_Port".equals(key_tContextLoad_1))
        {
           context.SMTP_Port=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Database".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Database=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Host".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Host=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Login".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Login=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Password".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Password=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Port".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Port=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TOM_DB_Schema".equals(key_tContextLoad_1))
        {
           context.TOM_DB_Schema=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TomTable_L".equals(key_tContextLoad_1))
        {
           context.TomTable_L=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "TomTable_S".equals(key_tContextLoad_1))
        {
           context.TomTable_S=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Username_CRM".equals(key_tContextLoad_1))
        {
           context.Username_CRM=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Username_DB_Landing".equals(key_tContextLoad_1))
        {
           context.Username_DB_Landing=value_tContextLoad_1;
        }

        if(key_tContextLoad_1!=null && "Username_DB_Staging".equals(key_tContextLoad_1))
        {
           context.Username_DB_Staging=value_tContextLoad_1;
        }


        if (context.getProperty(key_tContextLoad_1)!=null)
        {
            assignList_tContextLoad_1.add(key_tContextLoad_1);
        }else  {
            newPropertyList_tContextLoad_1.add(key_tContextLoad_1);
        }
        if(value_tContextLoad_1 == null){
            context.setProperty(key_tContextLoad_1, "");
        }else{
            context.setProperty(key_tContextLoad_1,value_tContextLoad_1);
        }
    }catch(java.lang.Exception e){
            log.error("tContextLoad_1 - Setting a value for the key \"" + key_tContextLoad_1 + "\" has failed. Error message: " + e.getMessage());
        System.err.println("Setting a value for the key \"" + key_tContextLoad_1 + "\" has failed. Error message: " + e.getMessage());
    }
        nb_line_tContextLoad_1++;
    }
        //////////////////////////

 


	tos_count_tContextLoad_1++;

/**
 * [tContextLoad_1 main ] stop
 */
	
	/**
	 * [tContextLoad_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 process_data_begin ] stop
 */
	
	/**
	 * [tContextLoad_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 process_data_end ] stop
 */

} // End of branch "copyOfcopyOfLoad"




	
	/**
	 * [tMap_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 process_data_end ] stop
 */

} // End of branch "row106"




	
	/**
	 * [tFileInputExcel_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 process_data_end ] stop
 */
	
	/**
	 * [tFileInputExcel_1 end ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

			}
			
			
				log.debug("tFileInputExcel_1 - Retrieved records count: "+ nb_line_tFileInputExcel_1 + " .");
			
			
			globalMap.put("tFileInputExcel_1_NB_LINE",nb_line_tFileInputExcel_1);
			
				}
			
		} finally { 
				
					if(!(source_tFileInputExcel_1 instanceof java.io.InputStream)){
						workbook_tFileInputExcel_1.close();
					}
				
		}	
		
 
                if(log.isDebugEnabled())
            log.debug("tFileInputExcel_1 - "  + ("Done.") );

ok_Hash.put("tFileInputExcel_1", true);
end_Hash.put("tFileInputExcel_1", System.currentTimeMillis());




/**
 * [tFileInputExcel_1 end ] stop
 */

	
	/**
	 * [tMap_1 end ] start
	 */

	

	
	
	currentComponent="tMap_1";

	


// ###############################
// # Lookup hashes releasing
// ###############################      
				log.debug("tMap_1 - Written records count in the table 'copyOfcopyOfLoad': " + count_copyOfcopyOfLoad_tMap_1 + ".");





			
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
	 				runStat.updateStatOnConnection("row106"+iterateId,2, 0);
			 	}
			}
			
			
			
			if(enableLogStash){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		
			 		RunStat.StatBean talend_statebean = runStat.logStatOnConnection("row106"+iterateId,2, 0);
			 		
			 		talendJobLog.addConnectionMessage(
					    "tFileInputExcel_1", 
					    "tFileInputExcel", 
					    false,
					    "output",
					    "row106",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					
			 		talendJobLog.addConnectionMessage(
					    "tMap_1", 
					    "tMap", 
					    true,
					    "input",
					    "row106",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					talendJobLogProcess(globalMap);
					
			 	}
			}
			
		
 
                if(log.isDebugEnabled())
            log.debug("tMap_1 - "  + ("Done.") );

ok_Hash.put("tMap_1", true);
end_Hash.put("tMap_1", System.currentTimeMillis());




/**
 * [tMap_1 end ] stop
 */

	
	/**
	 * [tContextLoad_1 end ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	
	
	java.util.Enumeration<?> enu_tContextLoad_1 = context.propertyNames();
    while(enu_tContextLoad_1.hasMoreElements())
    {           
    	String key_tContextLoad_1 = (String)enu_tContextLoad_1.nextElement();
        if(!assignList_tContextLoad_1.contains(key_tContextLoad_1) && !newPropertyList_tContextLoad_1.contains(key_tContextLoad_1))
        {
            noAssignList_tContextLoad_1.add(key_tContextLoad_1);
        }          
    } 

    String newPropertyStr_tContextLoad_1 = newPropertyList_tContextLoad_1.toString();
    String newProperty_tContextLoad_1 = newPropertyStr_tContextLoad_1.substring(1, newPropertyStr_tContextLoad_1.length() - 1);
    
    String noAssignStr_tContextLoad_1 = noAssignList_tContextLoad_1.toString();
    String noAssign_tContextLoad_1 = noAssignStr_tContextLoad_1.substring(1, noAssignStr_tContextLoad_1.length() - 1);
    
    globalMap.put("tContextLoad_1_KEY_NOT_INCONTEXT", newProperty_tContextLoad_1);
    globalMap.put("tContextLoad_1_KEY_NOT_LOADED", noAssign_tContextLoad_1);

    globalMap.put("tContextLoad_1_NB_LINE",nb_line_tContextLoad_1);

	List<String> parametersToEncrypt_tContextLoad_1 = new java.util.ArrayList<String>();
	
		parametersToEncrypt_tContextLoad_1.add("Password_CRM");
		
		parametersToEncrypt_tContextLoad_1.add("Password_DB_Landing");
		
		parametersToEncrypt_tContextLoad_1.add("Password_DB_Staging");
		
		parametersToEncrypt_tContextLoad_1.add("SIGMA_DB_Password");
		
		parametersToEncrypt_tContextLoad_1.add("TOM_DB_Password");
		
	
	resumeUtil.addLog("NODE", "NODE:tContextLoad_1", "", Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt_tContextLoad_1));    
    	log.info("tContextLoad_1 - Loaded contexts count: " + nb_line_tContextLoad_1 + ".");
    
			
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
	 				runStat.updateStatOnConnection("copyOfcopyOfLoad"+iterateId,2, 0);
			 	}
			}
			
			
			
			if(enableLogStash){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		
			 		RunStat.StatBean talend_statebean = runStat.logStatOnConnection("copyOfcopyOfLoad"+iterateId,2, 0);
			 		
			 		talendJobLog.addConnectionMessage(
					    "tMap_1", 
					    "tMap", 
					    false,
					    "output",
					    "copyOfcopyOfLoad",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					
			 		talendJobLog.addConnectionMessage(
					    "tContextLoad_1", 
					    "tContextLoad", 
					    true,
					    "input",
					    "copyOfcopyOfLoad",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					talendJobLogProcess(globalMap);
					
			 	}
			}
			
		
 
                if(log.isDebugEnabled())
            log.debug("tContextLoad_1 - "  + ("Done.") );

ok_Hash.put("tContextLoad_1", true);
end_Hash.put("tContextLoad_1", System.currentTimeMillis());




/**
 * [tContextLoad_1 end ] stop
 */






				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tFileInputExcel_1 finally ] start
	 */

	

	
	
	currentComponent="tFileInputExcel_1";

	

 



/**
 * [tFileInputExcel_1 finally ] stop
 */

	
	/**
	 * [tMap_1 finally ] start
	 */

	

	
	
	currentComponent="tMap_1";

	

 



/**
 * [tMap_1 finally ] stop
 */

	
	/**
	 * [tContextLoad_1 finally ] start
	 */

	

	
	
	currentComponent="tContextLoad_1";

	

 



/**
 * [tContextLoad_1 finally ] stop
 */






				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tFileInputExcel_1_SUBPROCESS_STATE", 1);
	}
	


public static class row3Struct implements routines.system.IPersistableRow<row3Struct> {
    final static byte[] commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];
    static byte[] commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String language;

				public String getLanguage () {
					return this.language;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String status;

				public String getStatus () {
					return this.status;
				}
				
			    public String substatus;

				public String getSubstatus () {
					return this.substatus;
				}
				
			    public String description;

				public String getDescription () {
					return this.description;
				}
				
			    public Object exception;

				public Object getException () {
					return this.exception;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length) {
				if(length < 1024 && commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length == 0) {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[1024];
				} else {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length);
			strReturn = new String(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.language = readString(dis);
					
					this.origin = readString(dis);
					
					this.status = readString(dis);
					
					this.substatus = readString(dis);
					
					this.description = readString(dis);
					
						this.exception = (Object) dis.readObject();
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		
			} catch(ClassNotFoundException eCNFE) {
				 throw new RuntimeException(eCNFE);
		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.language,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.status,dos);
					
					// String
				
						writeString(this.substatus,dos);
					
					// String
				
						writeString(this.description,dos);
					
					// Object
				
       			    	dos.writeObject(this.exception);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",language="+language);
		sb.append(",origin="+origin);
		sb.append(",status="+status);
		sb.append(",substatus="+substatus);
		sb.append(",description="+description);
		sb.append(",exception="+String.valueOf(exception));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(language == null){
        					sb.append("<null>");
        				}else{
            				sb.append(language);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(status == null){
        					sb.append("<null>");
        				}else{
            				sb.append(status);
            			}
            		
        			sb.append("|");
        		
        				if(substatus == null){
        					sb.append("<null>");
        				}else{
            				sb.append(substatus);
            			}
            		
        			sb.append("|");
        		
        				if(description == null){
        					sb.append("<null>");
        				}else{
            				sb.append(description);
            			}
            		
        			sb.append("|");
        		
        				if(exception == null){
        					sb.append("<null>");
        				}else{
            				sb.append(exception);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row3Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tAssertCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tAssertCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row3Struct row3 = new row3Struct();




	
	/**
	 * [tLogRow_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_1", false);
		start_Hash.put("tLogRow_1", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_1";

	
			if (execStat || enableLogStash) {
				if(resourceMap.get("inIterateVComp") == null){
					
						
						if(execStat) {
							runStat.updateStatOnConnection("row3"+iterateId, 0, 0);
						}
						
						
						
						if(enableLogStash) {
							runStat.logStatOnConnection("row3"+iterateId, 0, 0);
						}
						
					
				}
			} 

		
		int tos_count_tLogRow_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogRow_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogRow_1 = new StringBuilder();
                    log4jParamters_tLogRow_1.append("Parameters:");
                            log4jParamters_tLogRow_1.append("BASIC_MODE" + " = " + "false");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("TABLE_PRINT" + " = " + "true");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("VERTICAL" + " = " + "false");
                        log4jParamters_tLogRow_1.append(" | ");
                            log4jParamters_tLogRow_1.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                        log4jParamters_tLogRow_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + (log4jParamters_tLogRow_1) );
                    } 
                } 
            new BytesLimit65535_tLogRow_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tLogRow_1", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_1 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[10];

        public void addRow(String[] row) {

            for (int i = 0; i < 10; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 9 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 9 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[9] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_1 util_tLogRow_1 = new Util_tLogRow_1();
        util_tLogRow_1.setTableName("tLogRow_1");
        util_tLogRow_1.addRow(new String[]{"moment","pid","project","job","language","origin","status","substatus","description","exception",});        
 		StringBuilder strBuffer_tLogRow_1 = null;
		int nb_line_tLogRow_1 = 0;
///////////////////////    			



 



/**
 * [tLogRow_1 begin ] stop
 */



	
	/**
	 * [tAssertCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tAssertCatcher_1", false);
		start_Hash.put("tAssertCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tAssertCatcher_1";

	
		int tos_count_tAssertCatcher_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tAssertCatcher_1", "tAssertCatcher");
				talendJobLogProcess(globalMap);
			}
			

	for (AssertCatcherUtils.AssertCatcherMessage acm : tAssertCatcher_1.getMessages()) {
		row3.moment = acm.getMoment();
		row3.pid = acm.getPid();
		row3.project = acm.getProject();
		row3.job = acm.getJob();
		row3.language = acm.getLanguage();
		
		row3.origin = (acm.getOrigin()==null || acm.getOrigin().length()<1 ? null : acm.getOrigin());
	
    	row3.status = acm.getStatus();
		row3.substatus = acm.getSubstatus();
		row3.description = acm.getDescription();
		
		row3.exception = acm.getException();
		
 



/**
 * [tAssertCatcher_1 begin ] stop
 */
	
	/**
	 * [tAssertCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tAssertCatcher_1";

	

 


	tos_count_tAssertCatcher_1++;

/**
 * [tAssertCatcher_1 main ] stop
 */
	
	/**
	 * [tAssertCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tAssertCatcher_1";

	

 



/**
 * [tAssertCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tLogRow_1 main ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

			//row3
			//row3


			
				
				if(execStat){
					runStat.updateStatOnConnection("row3"+iterateId,1, 1);
				}
				
				
				
				if(enableLogStash) {
					runStat.logStatOnConnection("row3"+iterateId,1, 1);
				}
				
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row3 - " + (row3==null? "": row3.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_1 = new String[10];
   				
	    		if(row3.moment != null) { //              
                 row_tLogRow_1[0]=    						
								FormatterUtils.format_Date(row3.moment, "yyyy-MM-dd HH:mm:ss")
					          ;	
							
	    		} //			
    			   				
	    		if(row3.pid != null) { //              
                 row_tLogRow_1[1]=    						    
				                String.valueOf(row3.pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.project != null) { //              
                 row_tLogRow_1[2]=    						    
				                String.valueOf(row3.project)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.job != null) { //              
                 row_tLogRow_1[3]=    						    
				                String.valueOf(row3.job)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.language != null) { //              
                 row_tLogRow_1[4]=    						    
				                String.valueOf(row3.language)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.origin != null) { //              
                 row_tLogRow_1[5]=    						    
				                String.valueOf(row3.origin)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.status != null) { //              
                 row_tLogRow_1[6]=    						    
				                String.valueOf(row3.status)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.substatus != null) { //              
                 row_tLogRow_1[7]=    						    
				                String.valueOf(row3.substatus)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.description != null) { //              
                 row_tLogRow_1[8]=    						    
				                String.valueOf(row3.description)			
					          ;	
							
	    		} //			
    			   				
	    		if(row3.exception != null) { //              
                 row_tLogRow_1[9]=    						    
				                String.valueOf(row3.exception)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_1.addRow(row_tLogRow_1);	
				nb_line_tLogRow_1++;
                	log.info("tLogRow_1 - Content of row "+nb_line_tLogRow_1+": " + TalendString.unionString("|",row_tLogRow_1));
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_1++;

/**
 * [tLogRow_1 main ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 process_data_end ] stop
 */



	
	/**
	 * [tAssertCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tAssertCatcher_1";

	

 



/**
 * [tAssertCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tAssertCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tAssertCatcher_1";

	
	}
 

ok_Hash.put("tAssertCatcher_1", true);
end_Hash.put("tAssertCatcher_1", System.currentTimeMillis());




/**
 * [tAssertCatcher_1 end ] stop
 */

	
	/**
	 * [tLogRow_1 end ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_1 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_1 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_1 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_1);
                    }
                    
                    consoleOut_tLogRow_1.println(util_tLogRow_1.format().toString());
                    consoleOut_tLogRow_1.flush();
//////
globalMap.put("tLogRow_1_NB_LINE",nb_line_tLogRow_1);
                if(log.isInfoEnabled())
            log.info("tLogRow_1 - "  + ("Printed row count: ")  + (nb_line_tLogRow_1)  + (".") );

///////////////////////    			

			
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
	 				runStat.updateStatOnConnection("row3"+iterateId,2, 0);
			 	}
			}
			
			
			
			if(enableLogStash){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		
			 		RunStat.StatBean talend_statebean = runStat.logStatOnConnection("row3"+iterateId,2, 0);
			 		
			 		talendJobLog.addConnectionMessage(
					    "tAssertCatcher_1", 
					    "tAssertCatcher", 
					    false,
					    "output",
					    "row3",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					
			 		talendJobLog.addConnectionMessage(
					    "tLogRow_1", 
					    "tLogRow", 
					    true,
					    "input",
					    "row3",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					talendJobLogProcess(globalMap);
					
			 	}
			}
			
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_1 - "  + ("Done.") );

ok_Hash.put("tLogRow_1", true);
end_Hash.put("tLogRow_1", System.currentTimeMillis());




/**
 * [tLogRow_1 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tAssertCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tAssertCatcher_1";

	

 



/**
 * [tAssertCatcher_1 finally ] stop
 */

	
	/**
	 * [tLogRow_1 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_1";

	

 



/**
 * [tLogRow_1 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tAssertCatcher_1_SUBPROCESS_STATE", 1);
	}
	


public static class row2Struct implements routines.system.IPersistableRow<row2Struct> {
    final static byte[] commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];
    static byte[] commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[0];

	
			    public java.util.Date moment;

				public java.util.Date getMoment () {
					return this.moment;
				}
				
			    public String pid;

				public String getPid () {
					return this.pid;
				}
				
			    public String root_pid;

				public String getRoot_pid () {
					return this.root_pid;
				}
				
			    public String father_pid;

				public String getFather_pid () {
					return this.father_pid;
				}
				
			    public String project;

				public String getProject () {
					return this.project;
				}
				
			    public String job;

				public String getJob () {
					return this.job;
				}
				
			    public String context;

				public String getContext () {
					return this.context;
				}
				
			    public Integer priority;

				public Integer getPriority () {
					return this.priority;
				}
				
			    public String type;

				public String getType () {
					return this.type;
				}
				
			    public String origin;

				public String getOrigin () {
					return this.origin;
				}
				
			    public String message;

				public String getMessage () {
					return this.message;
				}
				
			    public Integer code;

				public Integer getCode () {
					return this.code;
				}
				



	private java.util.Date readDate(ObjectInputStream dis) throws IOException{
		java.util.Date dateReturn = null;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			dateReturn = null;
		} else {
	    	dateReturn = new Date(dis.readLong());
		}
		return dateReturn;
	}

    private void writeDate(java.util.Date date1, ObjectOutputStream dos) throws IOException{
		if(date1 == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeLong(date1.getTime());
    	}
    }

	private String readString(ObjectInputStream dis) throws IOException{
		String strReturn = null;
		int length = 0;
        length = dis.readInt();
		if (length == -1) {
			strReturn = null;
		} else {
			if(length > commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length) {
				if(length < 1024 && commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging.length == 0) {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[1024];
				} else {
   					commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging = new byte[2 * length];
   				}
			}
			dis.readFully(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length);
			strReturn = new String(commonByteArray_AMP_Phase1_1_Incremental_Quotes_Staging, 0, length, utf8Charset);
		}
		return strReturn;
	}

    private void writeString(String str, ObjectOutputStream dos) throws IOException{
		if(str == null) {
            dos.writeInt(-1);
		} else {
            byte[] byteArray = str.getBytes(utf8Charset);
	    	dos.writeInt(byteArray.length);
			dos.write(byteArray);
    	}
    }
	private Integer readInteger(ObjectInputStream dis) throws IOException{
		Integer intReturn;
        int length = 0;
        length = dis.readByte();
		if (length == -1) {
			intReturn = null;
		} else {
	    	intReturn = dis.readInt();
		}
		return intReturn;
	}

	private void writeInteger(Integer intNum, ObjectOutputStream dos) throws IOException{
		if(intNum == null) {
            dos.writeByte(-1);
		} else {
			dos.writeByte(0);
	    	dos.writeInt(intNum);
    	}
	}

    public void readData(ObjectInputStream dis) {

		synchronized(commonByteArrayLock_AMP_Phase1_1_Incremental_Quotes_Staging) {

        	try {

        		int length = 0;
		
					this.moment = readDate(dis);
					
					this.pid = readString(dis);
					
					this.root_pid = readString(dis);
					
					this.father_pid = readString(dis);
					
					this.project = readString(dis);
					
					this.job = readString(dis);
					
					this.context = readString(dis);
					
						this.priority = readInteger(dis);
					
					this.type = readString(dis);
					
					this.origin = readString(dis);
					
					this.message = readString(dis);
					
						this.code = readInteger(dis);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);

		

        }

		

      }


    }

    public void writeData(ObjectOutputStream dos) {
        try {

		
					// java.util.Date
				
						writeDate(this.moment,dos);
					
					// String
				
						writeString(this.pid,dos);
					
					// String
				
						writeString(this.root_pid,dos);
					
					// String
				
						writeString(this.father_pid,dos);
					
					// String
				
						writeString(this.project,dos);
					
					// String
				
						writeString(this.job,dos);
					
					// String
				
						writeString(this.context,dos);
					
					// Integer
				
						writeInteger(this.priority,dos);
					
					// String
				
						writeString(this.type,dos);
					
					// String
				
						writeString(this.origin,dos);
					
					// String
				
						writeString(this.message,dos);
					
					// Integer
				
						writeInteger(this.code,dos);
					
        	} catch (IOException e) {
	            throw new RuntimeException(e);
        }


    }


    public String toString() {

		StringBuilder sb = new StringBuilder();
		sb.append(super.toString());
		sb.append("[");
		sb.append("moment="+String.valueOf(moment));
		sb.append(",pid="+pid);
		sb.append(",root_pid="+root_pid);
		sb.append(",father_pid="+father_pid);
		sb.append(",project="+project);
		sb.append(",job="+job);
		sb.append(",context="+context);
		sb.append(",priority="+String.valueOf(priority));
		sb.append(",type="+type);
		sb.append(",origin="+origin);
		sb.append(",message="+message);
		sb.append(",code="+String.valueOf(code));
	    sb.append("]");

	    return sb.toString();
    }
        public String toLogString(){
        	StringBuilder sb = new StringBuilder();
        	
        				if(moment == null){
        					sb.append("<null>");
        				}else{
            				sb.append(moment);
            			}
            		
        			sb.append("|");
        		
        				if(pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(pid);
            			}
            		
        			sb.append("|");
        		
        				if(root_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(root_pid);
            			}
            		
        			sb.append("|");
        		
        				if(father_pid == null){
        					sb.append("<null>");
        				}else{
            				sb.append(father_pid);
            			}
            		
        			sb.append("|");
        		
        				if(project == null){
        					sb.append("<null>");
        				}else{
            				sb.append(project);
            			}
            		
        			sb.append("|");
        		
        				if(job == null){
        					sb.append("<null>");
        				}else{
            				sb.append(job);
            			}
            		
        			sb.append("|");
        		
        				if(context == null){
        					sb.append("<null>");
        				}else{
            				sb.append(context);
            			}
            		
        			sb.append("|");
        		
        				if(priority == null){
        					sb.append("<null>");
        				}else{
            				sb.append(priority);
            			}
            		
        			sb.append("|");
        		
        				if(type == null){
        					sb.append("<null>");
        				}else{
            				sb.append(type);
            			}
            		
        			sb.append("|");
        		
        				if(origin == null){
        					sb.append("<null>");
        				}else{
            				sb.append(origin);
            			}
            		
        			sb.append("|");
        		
        				if(message == null){
        					sb.append("<null>");
        				}else{
            				sb.append(message);
            			}
            		
        			sb.append("|");
        		
        				if(code == null){
        					sb.append("<null>");
        				}else{
            				sb.append(code);
            			}
            		
        			sb.append("|");
        		
        	return sb.toString();
        }

    /**
     * Compare keys
     */
    public int compareTo(row2Struct other) {

		int returnValue = -1;
		
	    return returnValue;
    }


    private int checkNullsAndCompare(Object object1, Object object2) {
        int returnValue = 0;
		if (object1 instanceof Comparable && object2 instanceof Comparable) {
            returnValue = ((Comparable) object1).compareTo(object2);
        } else if (object1 != null && object2 != null) {
            returnValue = compareStrings(object1.toString(), object2.toString());
        } else if (object1 == null && object2 != null) {
            returnValue = 1;
        } else if (object1 != null && object2 == null) {
            returnValue = -1;
        } else {
            returnValue = 0;
        }

        return returnValue;
    }

    private int compareStrings(String string1, String string2) {
        return string1.compareTo(string2);
    }


}
public void tLogCatcher_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		row2Struct row2 = new row2Struct();




	
	/**
	 * [tLogRow_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogRow_2", false);
		start_Hash.put("tLogRow_2", System.currentTimeMillis());
		
	
	currentComponent="tLogRow_2";

	
			if (execStat || enableLogStash) {
				if(resourceMap.get("inIterateVComp") == null){
					
						
						if(execStat) {
							runStat.updateStatOnConnection("row2"+iterateId, 0, 0);
						}
						
						
						
						if(enableLogStash) {
							runStat.logStatOnConnection("row2"+iterateId, 0, 0);
						}
						
					
				}
			} 

		
		int tos_count_tLogRow_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogRow_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogRow_2 = new StringBuilder();
                    log4jParamters_tLogRow_2.append("Parameters:");
                            log4jParamters_tLogRow_2.append("BASIC_MODE" + " = " + "false");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("TABLE_PRINT" + " = " + "true");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("VERTICAL" + " = " + "false");
                        log4jParamters_tLogRow_2.append(" | ");
                            log4jParamters_tLogRow_2.append("PRINT_CONTENT_WITH_LOG4J" + " = " + "true");
                        log4jParamters_tLogRow_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + (log4jParamters_tLogRow_2) );
                    } 
                } 
            new BytesLimit65535_tLogRow_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tLogRow_2", "tLogRow");
				talendJobLogProcess(globalMap);
			}
			

	///////////////////////
	
         class Util_tLogRow_2 {

        String[] des_top = { ".", ".", "-", "+" };

        String[] des_head = { "|=", "=|", "-", "+" };

        String[] des_bottom = { "'", "'", "-", "+" };

        String name="";

        java.util.List<String[]> list = new java.util.ArrayList<String[]>();

        int[] colLengths = new int[12];

        public void addRow(String[] row) {

            for (int i = 0; i < 12; i++) {
                if (row[i]!=null) {
                  colLengths[i] = Math.max(colLengths[i], row[i].length());
                }
            }
            list.add(row);
        }

        public void setTableName(String name) {

            this.name = name;
        }

            public StringBuilder format() {
            
                StringBuilder sb = new StringBuilder();
  
            
                    sb.append(print(des_top));
    
                    int totals = 0;
                    for (int i = 0; i < colLengths.length; i++) {
                        totals = totals + colLengths[i];
                    }
    
                    // name
                    sb.append("|");
                    int k = 0;
                    for (k = 0; k < (totals + 11 - name.length()) / 2; k++) {
                        sb.append(' ');
                    }
                    sb.append(name);
                    for (int i = 0; i < totals + 11 - name.length() - k; i++) {
                        sb.append(' ');
                    }
                    sb.append("|\n");

                    // head and rows
                    sb.append(print(des_head));
                    for (int i = 0; i < list.size(); i++) {
    
                        String[] row = list.get(i);
    
                        java.util.Formatter formatter = new java.util.Formatter(new StringBuilder());
                        
                        StringBuilder sbformat = new StringBuilder();                                             
        			        sbformat.append("|%1$-");
        			        sbformat.append(colLengths[0]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%2$-");
        			        sbformat.append(colLengths[1]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%3$-");
        			        sbformat.append(colLengths[2]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%4$-");
        			        sbformat.append(colLengths[3]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%5$-");
        			        sbformat.append(colLengths[4]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%6$-");
        			        sbformat.append(colLengths[5]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%7$-");
        			        sbformat.append(colLengths[6]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%8$-");
        			        sbformat.append(colLengths[7]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%9$-");
        			        sbformat.append(colLengths[8]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%10$-");
        			        sbformat.append(colLengths[9]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%11$-");
        			        sbformat.append(colLengths[10]);
        			        sbformat.append("s");
        			              
        			        sbformat.append("|%12$-");
        			        sbformat.append(colLengths[11]);
        			        sbformat.append("s");
        			                      
                        sbformat.append("|\n");                    
       
                        formatter.format(sbformat.toString(), (Object[])row);	
                                
                        sb.append(formatter.toString());
                        if (i == 0)
                            sb.append(print(des_head)); // print the head
                    }
    
                    // end
                    sb.append(print(des_bottom));
                    return sb;
                }
            

            private StringBuilder print(String[] fillChars) {
                StringBuilder sb = new StringBuilder();
                //first column
                sb.append(fillChars[0]);                
                    for (int i = 0; i < colLengths[0] - fillChars[0].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);	                

                    for (int i = 0; i < colLengths[1] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[2] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[3] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[4] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[5] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[6] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[7] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[8] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[9] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                    for (int i = 0; i < colLengths[10] - fillChars[3].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }
                    sb.append(fillChars[3]);
                
                    //last column
                    for (int i = 0; i < colLengths[11] - fillChars[1].length() + 1; i++) {
                        sb.append(fillChars[2]);
                    }         
                sb.append(fillChars[1]);
                sb.append("\n");               
                return sb;
            }
            
            public boolean isTableEmpty(){
            	if (list.size() > 1)
            		return false;
            	return true;
            }
        }
        Util_tLogRow_2 util_tLogRow_2 = new Util_tLogRow_2();
        util_tLogRow_2.setTableName("tLogRow_2");
        util_tLogRow_2.addRow(new String[]{"moment","pid","root_pid","father_pid","project","job","context","priority","type","origin","message","code",});        
 		StringBuilder strBuffer_tLogRow_2 = null;
		int nb_line_tLogRow_2 = 0;
///////////////////////    			



 



/**
 * [tLogRow_2 begin ] stop
 */



	
	/**
	 * [tLogCatcher_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tLogCatcher_1", false);
		start_Hash.put("tLogCatcher_1", System.currentTimeMillis());
		
	
	currentComponent="tLogCatcher_1";

	
		int tos_count_tLogCatcher_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tLogCatcher_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tLogCatcher_1 = new StringBuilder();
                    log4jParamters_tLogCatcher_1.append("Parameters:");
                            log4jParamters_tLogCatcher_1.append("CATCH_JAVA_EXCEPTION" + " = " + "true");
                        log4jParamters_tLogCatcher_1.append(" | ");
                            log4jParamters_tLogCatcher_1.append("CATCH_TDIE" + " = " + "true");
                        log4jParamters_tLogCatcher_1.append(" | ");
                            log4jParamters_tLogCatcher_1.append("CATCH_TWARN" + " = " + "true");
                        log4jParamters_tLogCatcher_1.append(" | ");
                            log4jParamters_tLogCatcher_1.append("CATCH_TACTIONFAILURE" + " = " + "true");
                        log4jParamters_tLogCatcher_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + (log4jParamters_tLogCatcher_1) );
                    } 
                } 
            new BytesLimit65535_tLogCatcher_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tLogCatcher_1", "tLogCatcher");
				talendJobLogProcess(globalMap);
			}
			

try {
	for (LogCatcherUtils.LogCatcherMessage lcm : tLogCatcher_1.getMessages()) {
		row2.type = lcm.getType();
		row2.origin = (lcm.getOrigin()==null || lcm.getOrigin().length()<1 ? null : lcm.getOrigin());
		row2.priority = lcm.getPriority();
		row2.message = lcm.getMessage();
		row2.code = lcm.getCode();
		
		row2.moment = java.util.Calendar.getInstance().getTime();
	
    	row2.pid = pid;
		row2.root_pid = rootPid;
		row2.father_pid = fatherPid;
	
    	row2.project = projectName;
    	row2.job = jobName;
    	row2.context = contextStr;
    		
 



/**
 * [tLogCatcher_1 begin ] stop
 */
	
	/**
	 * [tLogCatcher_1 main ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 


	tos_count_tLogCatcher_1++;

/**
 * [tLogCatcher_1 main ] stop
 */
	
	/**
	 * [tLogCatcher_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 process_data_begin ] stop
 */

	
	/**
	 * [tLogRow_2 main ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

			//row2
			//row2


			
				
				if(execStat){
					runStat.updateStatOnConnection("row2"+iterateId,1, 1);
				}
				
				
				
				if(enableLogStash) {
					runStat.logStatOnConnection("row2"+iterateId,1, 1);
				}
				
			

		
    			if(log.isTraceEnabled()){
    				log.trace("row2 - " + (row2==null? "": row2.toLogString()));
    			}
    		
///////////////////////		
						

				
				String[] row_tLogRow_2 = new String[12];
   				
	    		if(row2.moment != null) { //              
                 row_tLogRow_2[0]=    						
								FormatterUtils.format_Date(row2.moment, "yyyy-MM-dd HH:mm:ss")
					          ;	
							
	    		} //			
    			   				
	    		if(row2.pid != null) { //              
                 row_tLogRow_2[1]=    						    
				                String.valueOf(row2.pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.root_pid != null) { //              
                 row_tLogRow_2[2]=    						    
				                String.valueOf(row2.root_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.father_pid != null) { //              
                 row_tLogRow_2[3]=    						    
				                String.valueOf(row2.father_pid)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.project != null) { //              
                 row_tLogRow_2[4]=    						    
				                String.valueOf(row2.project)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.job != null) { //              
                 row_tLogRow_2[5]=    						    
				                String.valueOf(row2.job)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.context != null) { //              
                 row_tLogRow_2[6]=    						    
				                String.valueOf(row2.context)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.priority != null) { //              
                 row_tLogRow_2[7]=    						    
				                String.valueOf(row2.priority)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.type != null) { //              
                 row_tLogRow_2[8]=    						    
				                String.valueOf(row2.type)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.origin != null) { //              
                 row_tLogRow_2[9]=    						    
				                String.valueOf(row2.origin)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.message != null) { //              
                 row_tLogRow_2[10]=    						    
				                String.valueOf(row2.message)			
					          ;	
							
	    		} //			
    			   				
	    		if(row2.code != null) { //              
                 row_tLogRow_2[11]=    						    
				                String.valueOf(row2.code)			
					          ;	
							
	    		} //			
    			 

				util_tLogRow_2.addRow(row_tLogRow_2);	
				nb_line_tLogRow_2++;
                	log.info("tLogRow_2 - Content of row "+nb_line_tLogRow_2+": " + TalendString.unionString("|",row_tLogRow_2));
//////

//////                    
                    
///////////////////////    			

 


	tos_count_tLogRow_2++;

/**
 * [tLogRow_2 main ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_begin ] stop
 */
	
	/**
	 * [tLogRow_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 process_data_end ] stop
 */



	
	/**
	 * [tLogCatcher_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 process_data_end ] stop
 */
	
	/**
	 * [tLogCatcher_1 end ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	
	}
} catch (Exception e_tLogCatcher_1) {
	logIgnoredError(String.format("tLogCatcher_1 - tLogCatcher failed to process log message(s) due to internal error: %s", e_tLogCatcher_1), e_tLogCatcher_1);
}

 
                if(log.isDebugEnabled())
            log.debug("tLogCatcher_1 - "  + ("Done.") );

ok_Hash.put("tLogCatcher_1", true);
end_Hash.put("tLogCatcher_1", System.currentTimeMillis());




/**
 * [tLogCatcher_1 end ] stop
 */

	
	/**
	 * [tLogRow_2 end ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	


//////

                    
                    java.io.PrintStream consoleOut_tLogRow_2 = null;
                    if (globalMap.get("tLogRow_CONSOLE")!=null)
                    {
                    	consoleOut_tLogRow_2 = (java.io.PrintStream) globalMap.get("tLogRow_CONSOLE");
                    }
                    else
                    {
                    	consoleOut_tLogRow_2 = new java.io.PrintStream(new java.io.BufferedOutputStream(System.out));
                    	globalMap.put("tLogRow_CONSOLE",consoleOut_tLogRow_2);
                    }
                    
                    consoleOut_tLogRow_2.println(util_tLogRow_2.format().toString());
                    consoleOut_tLogRow_2.flush();
//////
globalMap.put("tLogRow_2_NB_LINE",nb_line_tLogRow_2);
                if(log.isInfoEnabled())
            log.info("tLogRow_2 - "  + ("Printed row count: ")  + (nb_line_tLogRow_2)  + (".") );

///////////////////////    			

			
			if(execStat){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
	 				runStat.updateStatOnConnection("row2"+iterateId,2, 0);
			 	}
			}
			
			
			
			if(enableLogStash){
				if(resourceMap.get("inIterateVComp") == null || !((Boolean)resourceMap.get("inIterateVComp"))){
			 		
			 		RunStat.StatBean talend_statebean = runStat.logStatOnConnection("row2"+iterateId,2, 0);
			 		
			 		talendJobLog.addConnectionMessage(
					    "tLogCatcher_1", 
					    "tLogCatcher", 
					    false,
					    "output",
					    "row2",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					
			 		talendJobLog.addConnectionMessage(
					    "tLogRow_2", 
					    "tLogRow", 
					    true,
					    "input",
					    "row2",
					    talend_statebean.getNbLine(),
					    talend_statebean.getStartTime(),
					    talend_statebean.getEndTime()
					);
					talendJobLogProcess(globalMap);
					
			 	}
			}
			
		
 
                if(log.isDebugEnabled())
            log.debug("tLogRow_2 - "  + ("Done.") );

ok_Hash.put("tLogRow_2", true);
end_Hash.put("tLogRow_2", System.currentTimeMillis());




/**
 * [tLogRow_2 end ] stop
 */



				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tLogCatcher_1 finally ] start
	 */

	

	
	
	currentComponent="tLogCatcher_1";

	

 



/**
 * [tLogCatcher_1 finally ] stop
 */

	
	/**
	 * [tLogRow_2 finally ] start
	 */

	

	
	
	currentComponent="tLogRow_2";

	

 



/**
 * [tLogRow_2 finally ] stop
 */



				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tLogCatcher_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_2", false);
		start_Hash.put("tJava_2", System.currentTimeMillis());
		
	
	currentComponent="tJava_2";

	
		int tos_count_tJava_2 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_2", "tJava");
				talendJobLogProcess(globalMap);
			}
			


java.io.File file = new java.io.File("C:/AMP/Incremental/Logs/Incremental_Quotes_Staging_Job_"+TalendDate.getDate("yyyyMMdd_HHmm")+".log");
//System.setOut(new java.io.PrintStream(new java.io.FileOutputStream(file, true), true));
java.io.PrintStream ps = new java.io.PrintStream(new java.io.FileOutputStream(file));
System.setOut(ps);

 



/**
 * [tJava_2 begin ] stop
 */
	
	/**
	 * [tJava_2 main ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 


	tos_count_tJava_2++;

/**
 * [tJava_2 main ] stop
 */
	
	/**
	 * [tJava_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 process_data_begin ] stop
 */
	
	/**
	 * [tJava_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 process_data_end ] stop
 */
	
	/**
	 * [tJava_2 end ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 

ok_Hash.put("tJava_2", true);
end_Hash.put("tJava_2", System.currentTimeMillis());




/**
 * [tJava_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk15", 0, "ok");
								} 
							
							tSendMail_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_2 finally ] start
	 */

	

	
	
	currentComponent="tJava_2";

	

 



/**
 * [tJava_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_2_SUBPROCESS_STATE", 1);
	}
	

public void tSendMail_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tSendMail_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_1", false);
		start_Hash.put("tSendMail_1", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_1";

	
		int tos_count_tSendMail_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSendMail_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSendMail_1 = new StringBuilder();
                    log4jParamters_tSendMail_1.append("Parameters:");
                            log4jParamters_tSendMail_1.append("TO" + " = " + "context.Mail_To");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("FROM" + " = " + "context.Mail_From");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("NEED_PERSONAL_NAME" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("CC" + " = " + "");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("BCC" + " = " + "");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SUBJECT" + " = " + "\"Incremental Quotes_Staging Job: Started\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("MESSAGE" + " = " + "\"Hello Team,     Incremental Quotes Job has been Completed Successfully.  Incremental Quotes_Staging Job has been triggered now.     Next Job: Incremental_CRM       Regards,  TalendServiceUser\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("CHECK_ATTACHMENT" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("ATTACHMENTS" + " = " + "[]");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("HEADERS" + " = " + "[]");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SMTP_HOST" + " = " + "context.SMTP_Host");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SMTP_PORT" + " = " + "context.SMTP_Port");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SSL" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("STARTTLS" + " = " + "true");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("IMPORTANCE" + " = " + "Normal");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("NEED_AUTH" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("TEXT_SUBTYPE" + " = " + "plain");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tSendMail_1.append(" | ");
                            log4jParamters_tSendMail_1.append("SET_LOCALHOST" + " = " + "false");
                        log4jParamters_tSendMail_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + (log4jParamters_tSendMail_1) );
                    } 
                } 
            new BytesLimit65535_tSendMail_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tSendMail_1", "tSendMail");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSendMail_1 begin ] stop
 */
	
	/**
	 * [tSendMail_1 main ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 

	String smtpHost_tSendMail_1 = context.SMTP_Host;
        String smtpPort_tSendMail_1 = context.SMTP_Port;
	String from_tSendMail_1 = (context.Mail_From);
    String to_tSendMail_1 = (context.Mail_To).replace(";",",");
    String cc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String bcc_tSendMail_1 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_1 = ("Incremental Quotes_Staging Job: Started");
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_1 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_1 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_1 = new java.util.ArrayList<String>();

	String message_tSendMail_1 = (("Hello Team,\n \nIncremental Quotes Job has been Completed Successfully.\nIncremental Quotes_Staging Job has been trigge"
+"red now. \n\nNext Job: Incremental_CRM\n \n\nRegards,\nTalendServiceUser") == null || "".equals("Hello Team,\n \nIncremental Quotes Job has been Completed Successfully.\nIncremental Quotes_Staging Job has been trigge"
+"red now. \n\nNext Job: Incremental_CRM\n \n\nRegards,\nTalendServiceUser")) ? "\"\"" : ("Hello Team,\n \nIncremental Quotes Job has been Completed Successfully.\nIncremental Quotes_Staging Job has been trigge"
+"red now. \n\nNext Job: Incremental_CRM\n \n\nRegards,\nTalendServiceUser") ;
	java.util.Properties props_tSendMail_1 = System.getProperties();     
	props_tSendMail_1.put("mail.smtp.host", smtpHost_tSendMail_1);
	props_tSendMail_1.put("mail.smtp.port", smtpPort_tSendMail_1);
		props_tSendMail_1.put("mail.mime.encodefilename", "true");
		props_tSendMail_1.put("mail.smtp.starttls.enable","true");     
	try {
		
			log.info("tSendMail_1 - Connection attempt to '" + smtpHost_tSendMail_1 +"'.");
		
		  
			props_tSendMail_1.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_1 = javax.mail.Session.getInstance(props_tSendMail_1, null);    
		
		
			log.info("tSendMail_1 - Connection to '" + smtpHost_tSendMail_1 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_1 = new javax.mail.internet.MimeMessage(session_tSendMail_1);
		msg_tSendMail_1.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_1, null));
		msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_1, false));
		if (cc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_1, false));
		if (bcc_tSendMail_1 != null) msg_tSendMail_1.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_1, false));
		msg_tSendMail_1.setSubject(subject_tSendMail_1);

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < headers_tSendMail_1.size(); i_tSendMail_1++) {
			java.util.Map<String, String> header_tSendMail_1 = headers_tSendMail_1.get(i_tSendMail_1);
			msg_tSendMail_1.setHeader(header_tSendMail_1.get("KEY"), header_tSendMail_1.get("VALUE"));    
		}  
		msg_tSendMail_1.setSentDate(new Date());
		msg_tSendMail_1.setHeader("X-Priority", "3"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_1 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_1.setText(message_tSendMail_1,"ISO-8859-15", "plain");
		mp_tSendMail_1.addBodyPart(mbpText_tSendMail_1);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_1 = null;

		for (int i_tSendMail_1 = 0; i_tSendMail_1 < attachments_tSendMail_1.size(); i_tSendMail_1++){
			String filename_tSendMail_1 = attachments_tSendMail_1.get(i_tSendMail_1);
			javax.activation.FileDataSource fds_tSendMail_1 = null;
			java.io.File file_tSendMail_1 = new java.io.File(filename_tSendMail_1);
			
				if (!file_tSendMail_1.exists()){
					continue;
				}
			
    		if (file_tSendMail_1.isDirectory()){
				java.io.File[] subFiles_tSendMail_1 = file_tSendMail_1.listFiles();
				for(java.io.File subFile_tSendMail_1 : subFiles_tSendMail_1){
					if (subFile_tSendMail_1.isFile()){
						fds_tSendMail_1 = new javax.activation.FileDataSource(subFile_tSendMail_1.getAbsolutePath());
						mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1));
						mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
						if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
					}
				}
    		}else{
				mbpFile_tSendMail_1 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_1 = new javax.activation.FileDataSource(filename_tSendMail_1);
				mbpFile_tSendMail_1.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_1)); 
				mbpFile_tSendMail_1.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_1.getName()));
				if(contentTransferEncoding_tSendMail_1.get(i_tSendMail_1).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_1.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_1.addBodyPart(mbpFile_tSendMail_1);
			}
		}
		// -- set the content --
		msg_tSendMail_1.setContent(mp_tSendMail_1);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_1 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_1.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_1.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_1.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_1.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_1.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_1);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_1);
	} catch(java.lang.Exception e){
  		
			throw(e);
		
	}finally{
		props_tSendMail_1.remove("mail.smtp.host");
		props_tSendMail_1.remove("mail.smtp.port");
		
		props_tSendMail_1.remove("mail.mime.encodefilename");
		
			props_tSendMail_1.remove("mail.smtp.starttls.enable");
		
		props_tSendMail_1.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_1++;

/**
 * [tSendMail_1 main ] stop
 */
	
	/**
	 * [tSendMail_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 process_data_begin ] stop
 */
	
	/**
	 * [tSendMail_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 process_data_end ] stop
 */
	
	/**
	 * [tSendMail_1 end ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_1 - "  + ("Done.") );

ok_Hash.put("tSendMail_1", true);
end_Hash.put("tSendMail_1", System.currentTimeMillis());




/**
 * [tSendMail_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tSendMail_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk16", 0, "ok");
								} 
							
							tDBConnection_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_1 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_1";

	

 



/**
 * [tSendMail_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_1", false);
		start_Hash.put("tDBConnection_1", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_1";

	
		int tos_count_tDBConnection_1 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_1{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_1 = new StringBuilder();
                    log4jParamters_tDBConnection_1.append("Parameters:");
                            log4jParamters_tDBConnection_1.append("DRIVER" + " = " + "JTDS");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("HOST" + " = " + "context.TOM_DB_Host");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PORT" + " = " + "context.TOM_DB_Port");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SCHEMA_DB" + " = " + "context.TOM_DB_Schema");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("DBNAME" + " = " + "context.TOM_DB_Database");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USER" + " = " + "context.TOM_DB_Login");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.TOM_DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("AUTO_COMMIT" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_1.append(" | ");
                            log4jParamters_tDBConnection_1.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_1.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + (log4jParamters_tDBConnection_1) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_1().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tDBConnection_1", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
			String url_tDBConnection_1 = "jdbc:jtds:sqlserver://" + context.TOM_DB_Host ;
		String port_tDBConnection_1 = context.TOM_DB_Port;
		String dbname_tDBConnection_1 = context.TOM_DB_Database ;
    	if (!"".equals(port_tDBConnection_1)) {
    		url_tDBConnection_1 += ":" + context.TOM_DB_Port;
    	}
    	if (!"".equals(dbname_tDBConnection_1)) {
    		
				url_tDBConnection_1 += "//" + context.TOM_DB_Database; 
    	}
		url_tDBConnection_1 += ";appName=" + projectName + ";" + "";  
		String dbUser_tDBConnection_1 = context.TOM_DB_Login;
		
		
			
	final String decryptedPassword_tDBConnection_1 = context.TOM_DB_Password; 
			String dbPwd_tDBConnection_1 = decryptedPassword_tDBConnection_1;
		
	java.sql.Connection conn_tDBConnection_1 = null;
	
		
			String driverClass_tDBConnection_1 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_1 = java.lang.Class.forName(driverClass_tDBConnection_1);
		
	    		log.debug("tDBConnection_1 - Driver ClassName: "+driverClass_tDBConnection_1+".");
			
	    		log.debug("tDBConnection_1 - Connection attempt to '" + url_tDBConnection_1 + "' with the username '" + dbUser_tDBConnection_1 + "'.");
			
				conn_tDBConnection_1 = java.sql.DriverManager.getConnection(url_tDBConnection_1,dbUser_tDBConnection_1,dbPwd_tDBConnection_1);
	    		log.debug("tDBConnection_1 - Connection to '" + url_tDBConnection_1 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_1", conn_tDBConnection_1);
	if (null != conn_tDBConnection_1) {
		
			log.debug("tDBConnection_1 - Connection is set auto commit to 'false'.");
			conn_tDBConnection_1.setAutoCommit(false);
	}

	globalMap.put("dbschema_tDBConnection_1", context.TOM_DB_Schema);

	globalMap.put("db_tDBConnection_1",  context.TOM_DB_Database);

	globalMap.put("conn_tDBConnection_1",conn_tDBConnection_1);
	
	globalMap.put("shareIdentitySetting_tDBConnection_1",  false);

 



/**
 * [tDBConnection_1 begin ] stop
 */
	
	/**
	 * [tDBConnection_1 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 


	tos_count_tDBConnection_1++;

/**
 * [tDBConnection_1 main ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_1 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_1 - "  + ("Done.") );

ok_Hash.put("tDBConnection_1", true);
end_Hash.put("tDBConnection_1", System.currentTimeMillis());




/**
 * [tDBConnection_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk1", 0, "ok");
								} 
							
							tDBConnection_2Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_1 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_1";

	

 



/**
 * [tDBConnection_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_1_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_2", false);
		start_Hash.put("tDBConnection_2", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_2";

	
		int tos_count_tDBConnection_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_2 = new StringBuilder();
                    log4jParamters_tDBConnection_2.append("Parameters:");
                            log4jParamters_tDBConnection_2.append("DRIVER" + " = " + "JTDS");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("HOST" + " = " + "context.SIGMA_DB_Host");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PORT" + " = " + "context.SIGMA_DB_Port");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SCHEMA_DB" + " = " + "context.SIGMA_DB_Schema");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("DBNAME" + " = " + "context.SIGMA_DB_Database");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USER" + " = " + "context.SIGMA_DB_Login");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.SIGMA_DB_Password)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("AUTO_COMMIT" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_2.append(" | ");
                            log4jParamters_tDBConnection_2.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + (log4jParamters_tDBConnection_2) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tDBConnection_2", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
			String url_tDBConnection_2 = "jdbc:jtds:sqlserver://" + context.SIGMA_DB_Host ;
		String port_tDBConnection_2 = context.SIGMA_DB_Port;
		String dbname_tDBConnection_2 = context.SIGMA_DB_Database ;
    	if (!"".equals(port_tDBConnection_2)) {
    		url_tDBConnection_2 += ":" + context.SIGMA_DB_Port;
    	}
    	if (!"".equals(dbname_tDBConnection_2)) {
    		
				url_tDBConnection_2 += "//" + context.SIGMA_DB_Database; 
    	}
		url_tDBConnection_2 += ";appName=" + projectName + ";" + "";  
		String dbUser_tDBConnection_2 = context.SIGMA_DB_Login;
		
		
			
	final String decryptedPassword_tDBConnection_2 = context.SIGMA_DB_Password; 
			String dbPwd_tDBConnection_2 = decryptedPassword_tDBConnection_2;
		
	java.sql.Connection conn_tDBConnection_2 = null;
	
		
			String driverClass_tDBConnection_2 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_2 = java.lang.Class.forName(driverClass_tDBConnection_2);
		
	    		log.debug("tDBConnection_2 - Driver ClassName: "+driverClass_tDBConnection_2+".");
			
	    		log.debug("tDBConnection_2 - Connection attempt to '" + url_tDBConnection_2 + "' with the username '" + dbUser_tDBConnection_2 + "'.");
			
				conn_tDBConnection_2 = java.sql.DriverManager.getConnection(url_tDBConnection_2,dbUser_tDBConnection_2,dbPwd_tDBConnection_2);
	    		log.debug("tDBConnection_2 - Connection to '" + url_tDBConnection_2 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_2", conn_tDBConnection_2);
	if (null != conn_tDBConnection_2) {
		
			log.debug("tDBConnection_2 - Connection is set auto commit to 'false'.");
			conn_tDBConnection_2.setAutoCommit(false);
	}

	globalMap.put("dbschema_tDBConnection_2", context.SIGMA_DB_Schema);

	globalMap.put("db_tDBConnection_2",  context.SIGMA_DB_Database);

	globalMap.put("conn_tDBConnection_2",conn_tDBConnection_2);
	
	globalMap.put("shareIdentitySetting_tDBConnection_2",  false);

 



/**
 * [tDBConnection_2 begin ] stop
 */
	
	/**
	 * [tDBConnection_2 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 


	tos_count_tDBConnection_2++;

/**
 * [tDBConnection_2 main ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_2 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_2 - "  + ("Done.") );

ok_Hash.put("tDBConnection_2", true);
end_Hash.put("tDBConnection_2", System.currentTimeMillis());




/**
 * [tDBConnection_2 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_2:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk2", 0, "ok");
								} 
							
							tDBConnection_3Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_2 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_2";

	

 



/**
 * [tDBConnection_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_2_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_3", false);
		start_Hash.put("tDBConnection_3", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_3";

	
		int tos_count_tDBConnection_3 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_3 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_3{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_3 = new StringBuilder();
                    log4jParamters_tDBConnection_3.append("Parameters:");
                            log4jParamters_tDBConnection_3.append("DRIVER" + " = " + "JTDS");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("HOST" + " = " + "context.Host_DB_Landing");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("PORT" + " = " + "context.Port_DB_Landing");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("SCHEMA_DB" + " = " + "context.Schema_DB_Landing");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("DBNAME" + " = " + "context.Database_DB_Landing");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("USER" + " = " + "context.Username_DB_Landing");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.Password_DB_Landing)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_3.append(" | ");
                            log4jParamters_tDBConnection_3.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_3.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_3 - "  + (log4jParamters_tDBConnection_3) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_3().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tDBConnection_3", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
			String url_tDBConnection_3 = "jdbc:jtds:sqlserver://" + context.Host_DB_Landing ;
		String port_tDBConnection_3 = context.Port_DB_Landing;
		String dbname_tDBConnection_3 = context.Database_DB_Landing ;
    	if (!"".equals(port_tDBConnection_3)) {
    		url_tDBConnection_3 += ":" + context.Port_DB_Landing;
    	}
    	if (!"".equals(dbname_tDBConnection_3)) {
    		
				url_tDBConnection_3 += "//" + context.Database_DB_Landing; 
    	}
		url_tDBConnection_3 += ";appName=" + projectName + ";" + "";  
		String dbUser_tDBConnection_3 = context.Username_DB_Landing;
		
		
			
	final String decryptedPassword_tDBConnection_3 = context.Password_DB_Landing; 
			String dbPwd_tDBConnection_3 = decryptedPassword_tDBConnection_3;
		
	java.sql.Connection conn_tDBConnection_3 = null;
	
		
			String driverClass_tDBConnection_3 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_3 = java.lang.Class.forName(driverClass_tDBConnection_3);
		
	    		log.debug("tDBConnection_3 - Driver ClassName: "+driverClass_tDBConnection_3+".");
			
	    		log.debug("tDBConnection_3 - Connection attempt to '" + url_tDBConnection_3 + "' with the username '" + dbUser_tDBConnection_3 + "'.");
			
				conn_tDBConnection_3 = java.sql.DriverManager.getConnection(url_tDBConnection_3,dbUser_tDBConnection_3,dbPwd_tDBConnection_3);
	    		log.debug("tDBConnection_3 - Connection to '" + url_tDBConnection_3 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_3", conn_tDBConnection_3);
	if (null != conn_tDBConnection_3) {
		
			log.debug("tDBConnection_3 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_3.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_3", context.Schema_DB_Landing);

	globalMap.put("db_tDBConnection_3",  context.Database_DB_Landing);

	globalMap.put("conn_tDBConnection_3",conn_tDBConnection_3);
	
	globalMap.put("shareIdentitySetting_tDBConnection_3",  false);

 



/**
 * [tDBConnection_3 begin ] stop
 */
	
	/**
	 * [tDBConnection_3 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_3";

	

 


	tos_count_tDBConnection_3++;

/**
 * [tDBConnection_3 main ] stop
 */
	
	/**
	 * [tDBConnection_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_3";

	

 



/**
 * [tDBConnection_3 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_3";

	

 



/**
 * [tDBConnection_3 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_3 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_3";

	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_3 - "  + ("Done.") );

ok_Hash.put("tDBConnection_3", true);
end_Hash.put("tDBConnection_3", System.currentTimeMillis());




/**
 * [tDBConnection_3 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_3:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk3", 0, "ok");
								} 
							
							tDBConnection_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_3 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_3";

	

 



/**
 * [tDBConnection_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_3_SUBPROCESS_STATE", 1);
	}
	

public void tDBConnection_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tDBConnection_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tDBConnection_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tDBConnection_4", false);
		start_Hash.put("tDBConnection_4", System.currentTimeMillis());
		
	
	currentComponent="tDBConnection_4";

	
		int tos_count_tDBConnection_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tDBConnection_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tDBConnection_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tDBConnection_4 = new StringBuilder();
                    log4jParamters_tDBConnection_4.append("Parameters:");
                            log4jParamters_tDBConnection_4.append("DRIVER" + " = " + "JTDS");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("HOST" + " = " + "context.Host_DB_Staging");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("PORT" + " = " + "context.Port_DB_Staging");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("SCHEMA_DB" + " = " + "context.Schema_DB_Staging");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("DBNAME" + " = " + "context.Database_DB_Staging");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("USER" + " = " + "context.Username_DB_Staging");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("PASS" + " = " + String.valueOf(routines.system.PasswordEncryptUtil.encryptPassword(context.Password_DB_Staging)).substring(0, 4) + "...");     
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("PROPERTIES" + " = " + "\"\"");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("USE_SHARED_CONNECTION" + " = " + "false");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("SPECIFY_DATASOURCE_ALIAS" + " = " + "false");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("AUTO_COMMIT" + " = " + "true");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("SHARE_IDENTITY_SETTING" + " = " + "false");
                        log4jParamters_tDBConnection_4.append(" | ");
                            log4jParamters_tDBConnection_4.append("UNIFIED_COMPONENTS" + " = " + "tMSSqlConnection");
                        log4jParamters_tDBConnection_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tDBConnection_4 - "  + (log4jParamters_tDBConnection_4) );
                    } 
                } 
            new BytesLimit65535_tDBConnection_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tDBConnection_4", "tMSSqlConnection");
				talendJobLogProcess(globalMap);
			}
			
	

	
			String url_tDBConnection_4 = "jdbc:jtds:sqlserver://" + context.Host_DB_Staging ;
		String port_tDBConnection_4 = context.Port_DB_Staging;
		String dbname_tDBConnection_4 = context.Database_DB_Staging ;
    	if (!"".equals(port_tDBConnection_4)) {
    		url_tDBConnection_4 += ":" + context.Port_DB_Staging;
    	}
    	if (!"".equals(dbname_tDBConnection_4)) {
    		
				url_tDBConnection_4 += "//" + context.Database_DB_Staging; 
    	}
		url_tDBConnection_4 += ";appName=" + projectName + ";" + "";  
		String dbUser_tDBConnection_4 = context.Username_DB_Staging;
		
		
			
	final String decryptedPassword_tDBConnection_4 = context.Password_DB_Staging; 
			String dbPwd_tDBConnection_4 = decryptedPassword_tDBConnection_4;
		
	java.sql.Connection conn_tDBConnection_4 = null;
	
		
			String driverClass_tDBConnection_4 = "net.sourceforge.jtds.jdbc.Driver";
			java.lang.Class jdbcclazz_tDBConnection_4 = java.lang.Class.forName(driverClass_tDBConnection_4);
		
	    		log.debug("tDBConnection_4 - Driver ClassName: "+driverClass_tDBConnection_4+".");
			
	    		log.debug("tDBConnection_4 - Connection attempt to '" + url_tDBConnection_4 + "' with the username '" + dbUser_tDBConnection_4 + "'.");
			
				conn_tDBConnection_4 = java.sql.DriverManager.getConnection(url_tDBConnection_4,dbUser_tDBConnection_4,dbPwd_tDBConnection_4);
	    		log.debug("tDBConnection_4 - Connection to '" + url_tDBConnection_4 + "' has succeeded.");
			

		globalMap.put("conn_tDBConnection_4", conn_tDBConnection_4);
	if (null != conn_tDBConnection_4) {
		
			log.debug("tDBConnection_4 - Connection is set auto commit to 'true'.");
			conn_tDBConnection_4.setAutoCommit(true);
	}

	globalMap.put("dbschema_tDBConnection_4", context.Schema_DB_Staging);

	globalMap.put("db_tDBConnection_4",  context.Database_DB_Staging);

	globalMap.put("conn_tDBConnection_4",conn_tDBConnection_4);
	
	globalMap.put("shareIdentitySetting_tDBConnection_4",  false);

 



/**
 * [tDBConnection_4 begin ] stop
 */
	
	/**
	 * [tDBConnection_4 main ] start
	 */

	

	
	
	currentComponent="tDBConnection_4";

	

 


	tos_count_tDBConnection_4++;

/**
 * [tDBConnection_4 main ] stop
 */
	
	/**
	 * [tDBConnection_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tDBConnection_4";

	

 



/**
 * [tDBConnection_4 process_data_begin ] stop
 */
	
	/**
	 * [tDBConnection_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tDBConnection_4";

	

 



/**
 * [tDBConnection_4 process_data_end ] stop
 */
	
	/**
	 * [tDBConnection_4 end ] start
	 */

	

	
	
	currentComponent="tDBConnection_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tDBConnection_4 - "  + ("Done.") );

ok_Hash.put("tDBConnection_4", true);
end_Hash.put("tDBConnection_4", System.currentTimeMillis());




/**
 * [tDBConnection_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tDBConnection_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk4", 0, "ok");
								} 
							
							tJava_1Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tDBConnection_4 finally ] start
	 */

	

	
	
	currentComponent="tDBConnection_4";

	

 



/**
 * [tDBConnection_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tDBConnection_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_1", false);
		start_Hash.put("tJava_1", System.currentTimeMillis());
		
	
	currentComponent="tJava_1";

	
		int tos_count_tJava_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_1", "tJava");
				talendJobLogProcess(globalMap);
			}
			




System.out.println(TalendDate.getCurrentDate() + ":- " + jobName + " Job is Started");
 



/**
 * [tJava_1 begin ] stop
 */
	
	/**
	 * [tJava_1 main ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 


	tos_count_tJava_1++;

/**
 * [tJava_1 main ] stop
 */
	
	/**
	 * [tJava_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_begin ] stop
 */
	
	/**
	 * [tJava_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 process_data_end ] stop
 */
	
	/**
	 * [tJava_1 end ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 

ok_Hash.put("tJava_1", true);
end_Hash.put("tJava_1", System.currentTimeMillis());




/**
 * [tJava_1 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_1:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk5", 0, "ok");
								} 
							
							tRunJob_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_1 finally ] start
	 */

	

	
	
	currentComponent="tJava_1";

	

 



/**
 * [tJava_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_1_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_5", false);
		start_Hash.put("tRunJob_5", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_5";

	
		int tos_count_tRunJob_5 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_5{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_5 = new StringBuilder();
                    log4jParamters_tRunJob_5.append("Parameters:");
                            log4jParamters_tRunJob_5.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROCESS" + " = " + "Phase1_1_Incremental_Sigma_Land_to_Stag_Deploy");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                            log4jParamters_tRunJob_5.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_5.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + (log4jParamters_tRunJob_5) );
                    } 
                } 
            new BytesLimit65535_tRunJob_5().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tRunJob_5", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_5 begin ] stop
 */
	
	/**
	 * [tRunJob_5 main ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	
	java.util.List<String> paraList_tRunJob_5 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_5.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_5.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_5.add("--father_node=tRunJob_5");
	      			
	        			paraList_tRunJob_5.add("--context=Test");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_5.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_5.add("--monitoring="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_5.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_5.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_5 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_5 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_5".equals(tRunJobName_tRunJob_5) && childResumePath_tRunJob_5 != null){
		paraList_tRunJob_5.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_5.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_5");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_5 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_5 = null;

	
	
		amp.phase1_1_incremental_sigma_land_to_stag_deploy_0_1.Phase1_1_Incremental_Sigma_Land_to_Stag_Deploy childJob_tRunJob_5 = new amp.phase1_1_incremental_sigma_land_to_stag_deploy_0_1.Phase1_1_Incremental_Sigma_Land_to_Stag_Deploy();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_5 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_5) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_5 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_5 : talendDataSources_tRunJob_5
			        .entrySet()) {
	            dataSources_tRunJob_5.put(talendDataSourceEntry_tRunJob_5.getKey(),
	                    talendDataSourceEntry_tRunJob_5.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_5.setDataSources(dataSources_tRunJob_5);
	    }
		  
			childJob_tRunJob_5.parentContextMap = parentContextMap_tRunJob_5;
		  
		
			log.info("tRunJob_5 - The child job 'amp.phase1_1_incremental_sigma_land_to_stag_deploy_0_1.Phase1_1_Incremental_Sigma_Land_to_Stag_Deploy' starts on the version '0.1' with the context 'Test'.");
		
		String[][] childReturn_tRunJob_5 = childJob_tRunJob_5.runJob((String[]) paraList_tRunJob_5.toArray(new String[paraList_tRunJob_5.size()]));
		
			log.info("tRunJob_5 - The child job 'amp.phase1_1_incremental_sigma_land_to_stag_deploy_0_1.Phase1_1_Incremental_Sigma_Land_to_Stag_Deploy' is done.");
		
	  	
				errorCode = childJob_tRunJob_5.getErrorCode();
		    
	            
	    	if(childJob_tRunJob_5.getErrorCode() == null){
				globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getStatus() != null && ("failure").equals(childJob_tRunJob_5.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_5_CHILD_RETURN_CODE", childJob_tRunJob_5.getErrorCode());
		    }
		    if (childJob_tRunJob_5.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_5_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_5.getExceptionStackTrace());
		    }
	  
			 
				if (childJob_tRunJob_5.getErrorCode() != null || ("failure").equals(childJob_tRunJob_5.getStatus())) {
					java.lang.Exception ce_tRunJob_5 = childJob_tRunJob_5.getException();
					throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_5!=null) ? (ce_tRunJob_5.getClass().getName() + ": " + ce_tRunJob_5.getMessage()) : ""));
				}
			
	  	

 


	tos_count_tRunJob_5++;

/**
 * [tRunJob_5 main ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 



/**
 * [tRunJob_5 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 



/**
 * [tRunJob_5 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_5 end ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_5 - "  + ("Done.") );

ok_Hash.put("tRunJob_5", true);
end_Hash.put("tRunJob_5", System.currentTimeMillis());




/**
 * [tRunJob_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk10", 0, "ok");
								} 
							
							tJava_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_5 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_5";

	

 



/**
 * [tRunJob_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_5_SUBPROCESS_STATE", 1);
	}
	

public void tJava_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_4", false);
		start_Hash.put("tJava_4", System.currentTimeMillis());
		
	
	currentComponent="tJava_4";

	
		int tos_count_tJava_4 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_4", "tJava");
				talendJobLogProcess(globalMap);
			}
			


System.out.println(TalendDate.getCurrentDate() + ":-  Sigma Incremental Landing to Staging Job is completed successfully");

System.out.println("************************************************************************************");

System.out.println(TalendDate.getCurrentDate() + ":-  Tom Incremental Landing to Staging Job is Starting Now");

System.out.println("************************************************************************************");
 



/**
 * [tJava_4 begin ] stop
 */
	
	/**
	 * [tJava_4 main ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 


	tos_count_tJava_4++;

/**
 * [tJava_4 main ] stop
 */
	
	/**
	 * [tJava_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 process_data_begin ] stop
 */
	
	/**
	 * [tJava_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 process_data_end ] stop
 */
	
	/**
	 * [tJava_4 end ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 

ok_Hash.put("tJava_4", true);
end_Hash.put("tJava_4", System.currentTimeMillis());




/**
 * [tJava_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk11", 0, "ok");
								} 
							
							tRunJob_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_4 finally ] start
	 */

	

	
	
	currentComponent="tJava_4";

	

 



/**
 * [tJava_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_4_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_6", false);
		start_Hash.put("tRunJob_6", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_6";

	
		int tos_count_tRunJob_6 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_6{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_6 = new StringBuilder();
                    log4jParamters_tRunJob_6.append("Parameters:");
                            log4jParamters_tRunJob_6.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PROCESS" + " = " + "Phase1_1_Incremental_Utom_Land_to_Stag_Deploy");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                            log4jParamters_tRunJob_6.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_6.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + (log4jParamters_tRunJob_6) );
                    } 
                } 
            new BytesLimit65535_tRunJob_6().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tRunJob_6", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_6 begin ] stop
 */
	
	/**
	 * [tRunJob_6 main ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	
	java.util.List<String> paraList_tRunJob_6 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_6.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_6.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_6.add("--father_node=tRunJob_6");
	      			
	        			paraList_tRunJob_6.add("--context=Test");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_6.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_6.add("--monitoring="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_6.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_6.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_6 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_6 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_6".equals(tRunJobName_tRunJob_6) && childResumePath_tRunJob_6 != null){
		paraList_tRunJob_6.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_6.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_6");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_6 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_6 = null;

	
	
		amp.phase1_1_incremental_utom_land_to_stag_deploy_0_1.Phase1_1_Incremental_Utom_Land_to_Stag_Deploy childJob_tRunJob_6 = new amp.phase1_1_incremental_utom_land_to_stag_deploy_0_1.Phase1_1_Incremental_Utom_Land_to_Stag_Deploy();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_6 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_6) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_6 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_6 : talendDataSources_tRunJob_6
			        .entrySet()) {
	            dataSources_tRunJob_6.put(talendDataSourceEntry_tRunJob_6.getKey(),
	                    talendDataSourceEntry_tRunJob_6.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_6.setDataSources(dataSources_tRunJob_6);
	    }
		  
			childJob_tRunJob_6.parentContextMap = parentContextMap_tRunJob_6;
		  
		
			log.info("tRunJob_6 - The child job 'amp.phase1_1_incremental_utom_land_to_stag_deploy_0_1.Phase1_1_Incremental_Utom_Land_to_Stag_Deploy' starts on the version '0.1' with the context 'Test'.");
		
		String[][] childReturn_tRunJob_6 = childJob_tRunJob_6.runJob((String[]) paraList_tRunJob_6.toArray(new String[paraList_tRunJob_6.size()]));
		
			log.info("tRunJob_6 - The child job 'amp.phase1_1_incremental_utom_land_to_stag_deploy_0_1.Phase1_1_Incremental_Utom_Land_to_Stag_Deploy' is done.");
		
	  	
				errorCode = childJob_tRunJob_6.getErrorCode();
		    
	            
	    	if(childJob_tRunJob_6.getErrorCode() == null){
				globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getStatus() != null && ("failure").equals(childJob_tRunJob_6.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_6_CHILD_RETURN_CODE", childJob_tRunJob_6.getErrorCode());
		    }
		    if (childJob_tRunJob_6.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_6_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_6.getExceptionStackTrace());
		    }
	  
			 
				if (childJob_tRunJob_6.getErrorCode() != null || ("failure").equals(childJob_tRunJob_6.getStatus())) {
					java.lang.Exception ce_tRunJob_6 = childJob_tRunJob_6.getException();
					throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_6!=null) ? (ce_tRunJob_6.getClass().getName() + ": " + ce_tRunJob_6.getMessage()) : ""));
				}
			
	  	

 


	tos_count_tRunJob_6++;

/**
 * [tRunJob_6 main ] stop
 */
	
	/**
	 * [tRunJob_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 



/**
 * [tRunJob_6 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 



/**
 * [tRunJob_6 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_6 end ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_6 - "  + ("Done.") );

ok_Hash.put("tRunJob_6", true);
end_Hash.put("tRunJob_6", System.currentTimeMillis());




/**
 * [tRunJob_6 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_6:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk12", 0, "ok");
								} 
							
							tJava_5Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_6 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_6";

	

 



/**
 * [tRunJob_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_6_SUBPROCESS_STATE", 1);
	}
	

public void tJava_5Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_5_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_5 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_5", false);
		start_Hash.put("tJava_5", System.currentTimeMillis());
		
	
	currentComponent="tJava_5";

	
		int tos_count_tJava_5 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_5", "tJava");
				talendJobLogProcess(globalMap);
			}
			


System.out.println(TalendDate.getCurrentDate() + ":-  Tom Incremental Landing to Staging Job is completed successfully");

System.out.println("************************************************************************************");

System.out.println(TalendDate.getCurrentDate() + ":-  Incremental Policies Unite Job is Starting Now");

System.out.println("************************************************************************************");
 



/**
 * [tJava_5 begin ] stop
 */
	
	/**
	 * [tJava_5 main ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 


	tos_count_tJava_5++;

/**
 * [tJava_5 main ] stop
 */
	
	/**
	 * [tJava_5 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 process_data_begin ] stop
 */
	
	/**
	 * [tJava_5 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 process_data_end ] stop
 */
	
	/**
	 * [tJava_5 end ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 

ok_Hash.put("tJava_5", true);
end_Hash.put("tJava_5", System.currentTimeMillis());




/**
 * [tJava_5 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tJava_5:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk13", 0, "ok");
								} 
							
							tRunJob_4Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_5 finally ] start
	 */

	

	
	
	currentComponent="tJava_5";

	

 



/**
 * [tJava_5 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_5_SUBPROCESS_STATE", 1);
	}
	

public void tRunJob_4Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tRunJob_4_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tRunJob_4 begin ] start
	 */

	

	
		
		ok_Hash.put("tRunJob_4", false);
		start_Hash.put("tRunJob_4", System.currentTimeMillis());
		
	
	currentComponent="tRunJob_4";

	
		int tos_count_tRunJob_4 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tRunJob_4{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tRunJob_4 = new StringBuilder();
                    log4jParamters_tRunJob_4.append("Parameters:");
                            log4jParamters_tRunJob_4.append("USE_DYNAMIC_JOB" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROCESS" + " = " + "Phase1_1_Incremental_Policies_Unite");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("USE_INDEPENDENT_PROCESS" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("DIE_ON_CHILD_ERROR" + " = " + "true");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("TRANSMIT_WHOLE_CONTEXT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("CONTEXTPARAMS" + " = " + "[]");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PROPAGATE_CHILD_RESULT" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                            log4jParamters_tRunJob_4.append("PRINT_PARAMETER" + " = " + "false");
                        log4jParamters_tRunJob_4.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + (log4jParamters_tRunJob_4) );
                    } 
                } 
            new BytesLimit65535_tRunJob_4().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tRunJob_4", "tRunJob");
				talendJobLogProcess(globalMap);
			}
			


 



/**
 * [tRunJob_4 begin ] stop
 */
	
	/**
	 * [tRunJob_4 main ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	
	java.util.List<String> paraList_tRunJob_4 = new java.util.ArrayList<String>();
	
	        			paraList_tRunJob_4.add("--father_pid="+pid);
	      			
	        			paraList_tRunJob_4.add("--root_pid="+rootPid);
	      			
	        			paraList_tRunJob_4.add("--father_node=tRunJob_4");
	      			
	        			paraList_tRunJob_4.add("--context=Default");
	      			
			if(!"".equals(log4jLevel)){
				paraList_tRunJob_4.add("--log4jLevel="+log4jLevel);
			}
		
		if(enableLogStash){
			paraList_tRunJob_4.add("--monitoring="+enableLogStash);
		}
		
	//for feature:10589
	
		paraList_tRunJob_4.add("--stat_port=" + portStats);
	

	if(resuming_logs_dir_path != null){
		paraList_tRunJob_4.add("--resuming_logs_dir_path=" + resuming_logs_dir_path);
	}
	String childResumePath_tRunJob_4 = ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path);
	String tRunJobName_tRunJob_4 = ResumeUtil.getRighttRunJob(resuming_checkpoint_path);
	if("tRunJob_4".equals(tRunJobName_tRunJob_4) && childResumePath_tRunJob_4 != null){
		paraList_tRunJob_4.add("--resuming_checkpoint_path=" + ResumeUtil.getChildJobCheckPointPath(resuming_checkpoint_path));
	}
	paraList_tRunJob_4.add("--parent_part_launcher=JOB:" + jobName + "/NODE:tRunJob_4");
	
	java.util.Map<String, Object> parentContextMap_tRunJob_4 = new java.util.HashMap<String, Object>();

	

	Object obj_tRunJob_4 = null;

	
	
		amp.phase1_1_incremental_policies_unite_0_1.Phase1_1_Incremental_Policies_Unite childJob_tRunJob_4 = new amp.phase1_1_incremental_policies_unite_0_1.Phase1_1_Incremental_Policies_Unite();
	    // pass DataSources
	    java.util.Map<String, routines.system.TalendDataSource> talendDataSources_tRunJob_4 = (java.util.Map<String, routines.system.TalendDataSource>) globalMap
	            .get(KEY_DB_DATASOURCES);
	    if (null != talendDataSources_tRunJob_4) {
	        java.util.Map<String, javax.sql.DataSource> dataSources_tRunJob_4 = new java.util.HashMap<String, javax.sql.DataSource>();
	        for (java.util.Map.Entry<String, routines.system.TalendDataSource> talendDataSourceEntry_tRunJob_4 : talendDataSources_tRunJob_4
			        .entrySet()) {
	            dataSources_tRunJob_4.put(talendDataSourceEntry_tRunJob_4.getKey(),
	                    talendDataSourceEntry_tRunJob_4.getValue().getRawDataSource());
	        }
	        childJob_tRunJob_4.setDataSources(dataSources_tRunJob_4);
	    }
		  
			childJob_tRunJob_4.parentContextMap = parentContextMap_tRunJob_4;
		  
		
			log.info("tRunJob_4 - The child job 'amp.phase1_1_incremental_policies_unite_0_1.Phase1_1_Incremental_Policies_Unite' starts on the version '0.1' with the context 'Default'.");
		
		String[][] childReturn_tRunJob_4 = childJob_tRunJob_4.runJob((String[]) paraList_tRunJob_4.toArray(new String[paraList_tRunJob_4.size()]));
		
			log.info("tRunJob_4 - The child job 'amp.phase1_1_incremental_policies_unite_0_1.Phase1_1_Incremental_Policies_Unite' is done.");
		
	  	
				errorCode = childJob_tRunJob_4.getErrorCode();
		    
	            
	    	if(childJob_tRunJob_4.getErrorCode() == null){
				globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getStatus() != null && ("failure").equals(childJob_tRunJob_4.getStatus()) ? 1 : 0);
	    	}else{
				globalMap.put("tRunJob_4_CHILD_RETURN_CODE", childJob_tRunJob_4.getErrorCode());
		    }
		    if (childJob_tRunJob_4.getExceptionStackTrace() != null) { 
		    	globalMap.put("tRunJob_4_CHILD_EXCEPTION_STACKTRACE", childJob_tRunJob_4.getExceptionStackTrace());
		    }
	  
			 
				if (childJob_tRunJob_4.getErrorCode() != null || ("failure").equals(childJob_tRunJob_4.getStatus())) {
					java.lang.Exception ce_tRunJob_4 = childJob_tRunJob_4.getException();
					throw new RuntimeException("Child job running failed.\n" + ((ce_tRunJob_4!=null) ? (ce_tRunJob_4.getClass().getName() + ": " + ce_tRunJob_4.getMessage()) : ""));
				}
			
	  	

 


	tos_count_tRunJob_4++;

/**
 * [tRunJob_4 main ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_begin ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 



/**
 * [tRunJob_4 process_data_begin ] stop
 */
	
	/**
	 * [tRunJob_4 process_data_end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 



/**
 * [tRunJob_4 process_data_end ] stop
 */
	
	/**
	 * [tRunJob_4 end ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 
                if(log.isDebugEnabled())
            log.debug("tRunJob_4 - "  + ("Done.") );

ok_Hash.put("tRunJob_4", true);
end_Hash.put("tRunJob_4", System.currentTimeMillis());




/**
 * [tRunJob_4 end ] stop
 */
				}//end the resume

				
				    			if(resumeEntryMethodName == null || globalResumeTicket){
				    				resumeUtil.addLog("CHECKPOINT", "CONNECTION:SUBJOB_OK:tRunJob_4:OnSubjobOk", "", Thread.currentThread().getId() + "", "", "", "", "", "");
								}	    				    			
					    	
								if(execStat){    	
									runStat.updateStatOnConnection("OnSubjobOk14", 0, "ok");
								} 
							
							tJava_6Process(globalMap); 
						



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tRunJob_4 finally ] start
	 */

	

	
	
	currentComponent="tRunJob_4";

	

 



/**
 * [tRunJob_4 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tRunJob_4_SUBPROCESS_STATE", 1);
	}
	

public void tJava_6Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_6_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tJava_6 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_6", false);
		start_Hash.put("tJava_6", System.currentTimeMillis());
		
	
	currentComponent="tJava_6";

	
		int tos_count_tJava_6 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_6", "tJava");
				talendJobLogProcess(globalMap);
			}
			


System.out.println(TalendDate.getCurrentDate() + ":-  Incremental Policies Unite Job is completed successfully");

System.out.println("************************************************************************************");

System.out.println(TalendDate.getCurrentDate() + ":- " + jobName + " Job is Completed Successfully");

System.out.println("************************************************************************************");
 



/**
 * [tJava_6 begin ] stop
 */
	
	/**
	 * [tJava_6 main ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 


	tos_count_tJava_6++;

/**
 * [tJava_6 main ] stop
 */
	
	/**
	 * [tJava_6 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 process_data_begin ] stop
 */
	
	/**
	 * [tJava_6 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 process_data_end ] stop
 */
	
	/**
	 * [tJava_6 end ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 

ok_Hash.put("tJava_6", true);
end_Hash.put("tJava_6", System.currentTimeMillis());




/**
 * [tJava_6 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_6 finally ] start
	 */

	

	
	
	currentComponent="tJava_6";

	

 



/**
 * [tJava_6 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_6_SUBPROCESS_STATE", 1);
	}
	

public void tPostjob_1Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tPostjob_1_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tPostjob_1 begin ] start
	 */

	

	
		
		ok_Hash.put("tPostjob_1", false);
		start_Hash.put("tPostjob_1", System.currentTimeMillis());
		
	
	currentComponent="tPostjob_1";

	
		int tos_count_tPostjob_1 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tPostjob_1", "tPostjob");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tPostjob_1 begin ] stop
 */
	
	/**
	 * [tPostjob_1 main ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 


	tos_count_tPostjob_1++;

/**
 * [tPostjob_1 main ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_begin ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_begin ] stop
 */
	
	/**
	 * [tPostjob_1 process_data_end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 process_data_end ] stop
 */
	
	/**
	 * [tPostjob_1 end ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 

ok_Hash.put("tPostjob_1", true);
end_Hash.put("tPostjob_1", System.currentTimeMillis());

				if(execStat){   
   	 				runStat.updateStatOnConnection("OnComponentOk2", 0, "ok");
				}
				tJava_3Process(globalMap);



/**
 * [tPostjob_1 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tPostjob_1 finally ] start
	 */

	

	
	
	currentComponent="tPostjob_1";

	

 



/**
 * [tPostjob_1 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tPostjob_1_SUBPROCESS_STATE", 1);
	}
	

public void tJava_3Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tJava_3_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;



		


	
	/**
	 * [tJava_3 begin ] start
	 */

	

	
		
		ok_Hash.put("tJava_3", false);
		start_Hash.put("tJava_3", System.currentTimeMillis());
		
	
	currentComponent="tJava_3";

	
		int tos_count_tJava_3 = 0;
		
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tJava_3", "tJava");
				talendJobLogProcess(globalMap);
			}
			



System.out.println("*****************************");
 



/**
 * [tJava_3 begin ] stop
 */
	
	/**
	 * [tJava_3 main ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 


	tos_count_tJava_3++;

/**
 * [tJava_3 main ] stop
 */
	
	/**
	 * [tJava_3 process_data_begin ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 process_data_begin ] stop
 */
	
	/**
	 * [tJava_3 process_data_end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 process_data_end ] stop
 */
	
	/**
	 * [tJava_3 end ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 

ok_Hash.put("tJava_3", true);
end_Hash.put("tJava_3", System.currentTimeMillis());

   			if (((Integer)globalMap.get("tLogRow_1_NB_LINE"))>0 || ((Integer)globalMap.get("tLogRow_2_NB_LINE"))>0) {
   				
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "true");
					}
				
    			tSendMail_2Process(globalMap);
   			}

			   
   				else{
					if(execStat){   
   	 					runStat.updateStatOnConnection("If1", 0, "false");
					}   	 
   				}



/**
 * [tJava_3 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tJava_3 finally ] start
	 */

	

	
	
	currentComponent="tJava_3";

	

 



/**
 * [tJava_3 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tJava_3_SUBPROCESS_STATE", 1);
	}
	

public void tSendMail_2Process(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("tSendMail_2_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [tSendMail_2 begin ] start
	 */

	

	
		
		ok_Hash.put("tSendMail_2", false);
		start_Hash.put("tSendMail_2", System.currentTimeMillis());
		
	
	currentComponent="tSendMail_2";

	
		int tos_count_tSendMail_2 = 0;
		
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Start to work.") );
            if (log.isDebugEnabled()) {
                class BytesLimit65535_tSendMail_2{
                    public void limitLog4jByte() throws Exception{
                    StringBuilder log4jParamters_tSendMail_2 = new StringBuilder();
                    log4jParamters_tSendMail_2.append("Parameters:");
                            log4jParamters_tSendMail_2.append("TO" + " = " + "context.Mail_To");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("FROM" + " = " + "context.Mail_From");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("NEED_PERSONAL_NAME" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("CC" + " = " + "");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("BCC" + " = " + "");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SUBJECT" + " = " + "\"Incremental Quotes_Staging Job: FAILED\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("MESSAGE" + " = " + "\"Hello Team,    Incremental Quotes_Staging Job is failed.  For further details please refer the logs attached.  Log Path: C:/AMP/Incremental/Logs    Regards,  TalendServiceUser\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("CHECK_ATTACHMENT" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("ATTACHMENTS" + " = " + "[{CONTENT_TRANSFER_ENCODING="+("DEFAULT")+", FILE="+("\"C:/AMP/Incremental/Logs/Incremental_Quotes_Staging_Job_\"+TalendDate.getDate(\"yyyyMMdd_HHmm\")+\".log\"")+"}, {CONTENT_TRANSFER_ENCODING="+("DEFAULT")+", FILE="+("\"C:/AMP/Incremental/Logs/Incremental_Sigma_LandingToStaging_\"+TalendDate.getDate(\"yyyyMMdd_HHmm\")+\".log\"")+"}, {CONTENT_TRANSFER_ENCODING="+("DEFAULT")+", FILE="+("\"C:/AMP/Incremental/Logs/Incremental_Tom_LandingToStaging_\"+TalendDate.getDate(\"yyyyMMdd_HHmm\")+\".log\"")+"}, {CONTENT_TRANSFER_ENCODING="+("DEFAULT")+", FILE="+("\"C:/AMP/Incremental/Logs/Incremental_Policies_Unite_Job_\"+TalendDate.getDate(\"yyyyMMdd_HHmm\")+\".log\"")+"}]");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("HEADERS" + " = " + "[]");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SMTP_HOST" + " = " + "context.SMTP_Host");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SMTP_PORT" + " = " + "context.SMTP_Port");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SSL" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("STARTTLS" + " = " + "true");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("IMPORTANCE" + " = " + "Normal");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("NEED_AUTH" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("DIE_ON_ERROR" + " = " + "true");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("TEXT_SUBTYPE" + " = " + "plain");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("ENCODING" + " = " + "\"ISO-8859-15\"");
                        log4jParamters_tSendMail_2.append(" | ");
                            log4jParamters_tSendMail_2.append("SET_LOCALHOST" + " = " + "false");
                        log4jParamters_tSendMail_2.append(" | ");
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + (log4jParamters_tSendMail_2) );
                    } 
                } 
            new BytesLimit65535_tSendMail_2().limitLog4jByte();
            }
			if(enableLogStash) {
				talendJobLog.addComponentMessage("tSendMail_2", "tSendMail");
				talendJobLogProcess(globalMap);
			}
			

 



/**
 * [tSendMail_2 begin ] stop
 */
	
	/**
	 * [tSendMail_2 main ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 

	String smtpHost_tSendMail_2 = context.SMTP_Host;
        String smtpPort_tSendMail_2 = context.SMTP_Port;
	String from_tSendMail_2 = (context.Mail_From);
    String to_tSendMail_2 = (context.Mail_To).replace(";",",");
    String cc_tSendMail_2 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String bcc_tSendMail_2 = (("")==null || "".equals(""))?null:("").replace(";",",");
    String subject_tSendMail_2 = ("Incremental Quotes_Staging Job: FAILED");
    
	java.util.List<java.util.Map<String, String>> headers_tSendMail_2 = new java.util.ArrayList<java.util.Map<String,String>>();
	java.util.List<String> attachments_tSendMail_2 = new java.util.ArrayList<String>();
	java.util.List<String> contentTransferEncoding_tSendMail_2 = new java.util.ArrayList<String>();
		attachments_tSendMail_2.add("C:/AMP/Incremental/Logs/Incremental_Quotes_Staging_Job_"+TalendDate.getDate("yyyyMMdd_HHmm")+".log");
		contentTransferEncoding_tSendMail_2.add("DEFAULT");	
		attachments_tSendMail_2.add("C:/AMP/Incremental/Logs/Incremental_Sigma_LandingToStaging_"+TalendDate.getDate("yyyyMMdd_HHmm")+".log");
		contentTransferEncoding_tSendMail_2.add("DEFAULT");	
		attachments_tSendMail_2.add("C:/AMP/Incremental/Logs/Incremental_Tom_LandingToStaging_"+TalendDate.getDate("yyyyMMdd_HHmm")+".log");
		contentTransferEncoding_tSendMail_2.add("DEFAULT");	
		attachments_tSendMail_2.add("C:/AMP/Incremental/Logs/Incremental_Policies_Unite_Job_"+TalendDate.getDate("yyyyMMdd_HHmm")+".log");
		contentTransferEncoding_tSendMail_2.add("DEFAULT");	

	String message_tSendMail_2 = (("Hello Team,\n\nIncremental Quotes_Staging Job is failed.\nFor further details please refer the logs attached.\nLog Path"
+": C:/AMP/Incremental/Logs\n\nRegards,\nTalendServiceUser") == null || "".equals("Hello Team,\n\nIncremental Quotes_Staging Job is failed.\nFor further details please refer the logs attached.\nLog Path"
+": C:/AMP/Incremental/Logs\n\nRegards,\nTalendServiceUser")) ? "\"\"" : ("Hello Team,\n\nIncremental Quotes_Staging Job is failed.\nFor further details please refer the logs attached.\nLog Path"
+": C:/AMP/Incremental/Logs\n\nRegards,\nTalendServiceUser") ;
	java.util.Properties props_tSendMail_2 = System.getProperties();     
	props_tSendMail_2.put("mail.smtp.host", smtpHost_tSendMail_2);
	props_tSendMail_2.put("mail.smtp.port", smtpPort_tSendMail_2);
		props_tSendMail_2.put("mail.mime.encodefilename", "true");
		props_tSendMail_2.put("mail.smtp.starttls.enable","true");     
	try {
		
			log.info("tSendMail_2 - Connection attempt to '" + smtpHost_tSendMail_2 +"'.");
		
		  
			props_tSendMail_2.put("mail.smtp.auth", "false");
			javax.mail.Session session_tSendMail_2 = javax.mail.Session.getInstance(props_tSendMail_2, null);    
		
		
			log.info("tSendMail_2 - Connection to '" + smtpHost_tSendMail_2 + "' has succeeded.");
		
		javax.mail.Message msg_tSendMail_2 = new javax.mail.internet.MimeMessage(session_tSendMail_2);
		msg_tSendMail_2.setFrom(new javax.mail.internet.InternetAddress(from_tSendMail_2, null));
		msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.TO,javax.mail.internet.InternetAddress.parse(to_tSendMail_2, false));
		if (cc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.CC, javax.mail.internet.InternetAddress.parse(cc_tSendMail_2, false));
		if (bcc_tSendMail_2 != null) msg_tSendMail_2.setRecipients(javax.mail.Message.RecipientType.BCC, javax.mail.internet.InternetAddress.parse(bcc_tSendMail_2, false));
		msg_tSendMail_2.setSubject(subject_tSendMail_2);

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < headers_tSendMail_2.size(); i_tSendMail_2++) {
			java.util.Map<String, String> header_tSendMail_2 = headers_tSendMail_2.get(i_tSendMail_2);
			msg_tSendMail_2.setHeader(header_tSendMail_2.get("KEY"), header_tSendMail_2.get("VALUE"));    
		}  
		msg_tSendMail_2.setSentDate(new Date());
		msg_tSendMail_2.setHeader("X-Priority", "3"); //High->1 Normal->3 Low->5
		javax.mail.Multipart mp_tSendMail_2 = new javax.mail.internet.MimeMultipart();
		javax.mail.internet.MimeBodyPart mbpText_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
		mbpText_tSendMail_2.setText(message_tSendMail_2,"ISO-8859-15", "plain");
		mp_tSendMail_2.addBodyPart(mbpText_tSendMail_2);
  
		javax.mail.internet.MimeBodyPart mbpFile_tSendMail_2 = null;

		for (int i_tSendMail_2 = 0; i_tSendMail_2 < attachments_tSendMail_2.size(); i_tSendMail_2++){
			String filename_tSendMail_2 = attachments_tSendMail_2.get(i_tSendMail_2);
			javax.activation.FileDataSource fds_tSendMail_2 = null;
			java.io.File file_tSendMail_2 = new java.io.File(filename_tSendMail_2);
			
				if (!file_tSendMail_2.exists()){
					continue;
				}
			
    		if (file_tSendMail_2.isDirectory()){
				java.io.File[] subFiles_tSendMail_2 = file_tSendMail_2.listFiles();
				for(java.io.File subFile_tSendMail_2 : subFiles_tSendMail_2){
					if (subFile_tSendMail_2.isFile()){
						fds_tSendMail_2 = new javax.activation.FileDataSource(subFile_tSendMail_2.getAbsolutePath());
						mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
						mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2));
						mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
						if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
							mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
						}
						mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
					}
				}
    		}else{
				mbpFile_tSendMail_2 = new javax.mail.internet.MimeBodyPart();
				fds_tSendMail_2 = new javax.activation.FileDataSource(filename_tSendMail_2);
				mbpFile_tSendMail_2.setDataHandler(new javax.activation.DataHandler(fds_tSendMail_2)); 
				mbpFile_tSendMail_2.setFileName(javax.mail.internet.MimeUtility.encodeText(fds_tSendMail_2.getName()));
				if(contentTransferEncoding_tSendMail_2.get(i_tSendMail_2).equalsIgnoreCase("base64")){
					mbpFile_tSendMail_2.setHeader("Content-Transfer-Encoding", "base64");
				}
				mp_tSendMail_2.addBodyPart(mbpFile_tSendMail_2);
			}
		}
		// -- set the content --
		msg_tSendMail_2.setContent(mp_tSendMail_2);
		// add handlers for main MIME types
		javax.activation.MailcapCommandMap mc_tSendMail_2 = ( javax.activation.MailcapCommandMap)javax.activation.CommandMap.getDefaultCommandMap();
		mc_tSendMail_2.addMailcap("text/html;; x-java-content-handler=com.sun.mail.handlers.text_html");
		mc_tSendMail_2.addMailcap("text/xml;; x-java-content-handler=com.sun.mail.handlers.text_xml");
		mc_tSendMail_2.addMailcap("text/plain;; x-java-content-handler=com.sun.mail.handlers.text_plain");
		mc_tSendMail_2.addMailcap("multipart/*;; x-java-content-handler=com.sun.mail.handlers.multipart_mixed");
		mc_tSendMail_2.addMailcap("message/rfc822;; x-java-content-handler=com.sun.mail.handlers.message_rfc822");
		javax.activation.CommandMap.setDefaultCommandMap(mc_tSendMail_2);
		// -- Send the message --
		javax.mail.Transport.send(msg_tSendMail_2);
	} catch(java.lang.Exception e){
  		
			throw(e);
		
	}finally{
		props_tSendMail_2.remove("mail.smtp.host");
		props_tSendMail_2.remove("mail.smtp.port");
		
		props_tSendMail_2.remove("mail.mime.encodefilename");
		
			props_tSendMail_2.remove("mail.smtp.starttls.enable");
		
		props_tSendMail_2.remove("mail.smtp.auth");     
	}

 


	tos_count_tSendMail_2++;

/**
 * [tSendMail_2 main ] stop
 */
	
	/**
	 * [tSendMail_2 process_data_begin ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 



/**
 * [tSendMail_2 process_data_begin ] stop
 */
	
	/**
	 * [tSendMail_2 process_data_end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 



/**
 * [tSendMail_2 process_data_end ] stop
 */
	
	/**
	 * [tSendMail_2 end ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 
                if(log.isDebugEnabled())
            log.debug("tSendMail_2 - "  + ("Done.") );

ok_Hash.put("tSendMail_2", true);
end_Hash.put("tSendMail_2", System.currentTimeMillis());




/**
 * [tSendMail_2 end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [tSendMail_2 finally ] start
	 */

	

	
	
	currentComponent="tSendMail_2";

	

 



/**
 * [tSendMail_2 finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("tSendMail_2_SUBPROCESS_STATE", 1);
	}
	

public void talendJobLogProcess(final java.util.Map<String, Object> globalMap) throws TalendException {
	globalMap.put("talendJobLog_SUBPROCESS_STATE", 0);

 final boolean execStat = this.execStat;
	
		String iterateId = "";
	
	
	String currentComponent = "";
	java.util.Map<String, Object> resourceMap = new java.util.HashMap<String, Object>();

	try {
			// TDI-39566 avoid throwing an useless Exception
			boolean resumeIt = true;
			if (globalResumeTicket == false && resumeEntryMethodName != null) {
				String currentMethodName = new java.lang.Exception().getStackTrace()[0].getMethodName();
				resumeIt = resumeEntryMethodName.equals(currentMethodName);
			}
			if (resumeIt || globalResumeTicket) { //start the resume
				globalResumeTicket = true;





	
	/**
	 * [talendJobLog begin ] start
	 */

	

	
		
		ok_Hash.put("talendJobLog", false);
		start_Hash.put("talendJobLog", System.currentTimeMillis());
		
	
	currentComponent="talendJobLog";

	
		int tos_count_talendJobLog = 0;
		

	for (JobStructureCatcherUtils.JobStructureCatcherMessage jcm : talendJobLog.getMessages()) {
		org.talend.logging.audit.Context log_context_talendJobLog = null;
		if(jcm.component_name == null) {//job level log
			if(jcm.status == null) {//job start
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version).timestamp(jcm.moment).build();
				auditLogger_talendJobLog.jobstart(log_context_talendJobLog);
			} else {//job end
				long timeMS = jcm.end_time - jcm.start_time;
				String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.timestamp(jcm.moment).duration(duration).status(jcm.status).build();
				auditLogger_talendJobLog.jobstop(log_context_talendJobLog);
			}
		} else if(jcm.current_connector == null) {//component log
			log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
				.connectorType(jcm.component_name).connectorId(jcm.component_id).build();
			auditLogger_talendJobLog.runcomponent(log_context_talendJobLog);
		} else {//component connector meter log
			long timeMS = jcm.end_time - jcm.start_time;
			String duration = String.format(java.util.Locale.US, "%1$.2fs", (timeMS * 1.0)/1000);
			
			if(jcm.current_connector_as_input) {//log current component input line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowInput(log_context_talendJobLog);
			} else {//log current component output/reject line
				log_context_talendJobLog = org.talend.job.audit.JobContextBuilder.create().jobName(jcm.job_name).jobId(jcm.job_id).jobVersion(jcm.job_version)
					.connectorType(jcm.component_name).connectorId(jcm.component_id)
					.connectionName(jcm.current_connector).connectionType(jcm.current_connector_type)
					.rows(jcm.total_row_number).duration(duration).build();
				auditLogger_talendJobLog.flowOutput(log_context_talendJobLog);
			}
		}
	}

 



/**
 * [talendJobLog begin ] stop
 */
	
	/**
	 * [talendJobLog main ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 


	tos_count_talendJobLog++;

/**
 * [talendJobLog main ] stop
 */
	
	/**
	 * [talendJobLog process_data_begin ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_begin ] stop
 */
	
	/**
	 * [talendJobLog process_data_end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog process_data_end ] stop
 */
	
	/**
	 * [talendJobLog end ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 

ok_Hash.put("talendJobLog", true);
end_Hash.put("talendJobLog", System.currentTimeMillis());




/**
 * [talendJobLog end ] stop
 */
				}//end the resume

				



	
			}catch(java.lang.Exception e){	
				
				    if(!(e instanceof TalendException)){
					   log.fatal(currentComponent + " " + e.getMessage(),e);
					}
				
				TalendException te = new TalendException(e, currentComponent, globalMap);
				
				throw te;
			}catch(java.lang.Error error){	
				
					runStat.stopThreadStat();
				
				throw error;
			}finally{
				
				try{
					
	
	/**
	 * [talendJobLog finally ] start
	 */

	

	
	
	currentComponent="talendJobLog";

	

 



/**
 * [talendJobLog finally ] stop
 */
				}catch(java.lang.Exception e){	
					//ignore
				}catch(java.lang.Error error){
					//ignore
				}
				resourceMap = null;
			}
		

		globalMap.put("talendJobLog_SUBPROCESS_STATE", 1);
	}
	
    public String resuming_logs_dir_path = null;
    public String resuming_checkpoint_path = null;
    public String parent_part_launcher = null;
    private String resumeEntryMethodName = null;
    private boolean globalResumeTicket = false;

    public boolean watch = false;
    // portStats is null, it means don't execute the statistics
    public Integer portStats = null;
    public int portTraces = 4334;
    public String clientHost;
    public String defaultClientHost = "localhost";
    public String contextStr = "Default";
    public boolean isDefaultContext = true;
    public String pid = "0";
    public String rootPid = null;
    public String fatherPid = null;
    public String fatherNode = null;
    public long startTime = 0;
    public boolean isChildJob = false;
    public String log4jLevel = "";
    
    private boolean enableLogStash;

    private boolean execStat = true;

    private ThreadLocal<java.util.Map<String, String>> threadLocal = new ThreadLocal<java.util.Map<String, String>>() {
        protected java.util.Map<String, String> initialValue() {
            java.util.Map<String,String> threadRunResultMap = new java.util.HashMap<String, String>();
            threadRunResultMap.put("errorCode", null);
            threadRunResultMap.put("status", "");
            return threadRunResultMap;
        };
    };


    private PropertiesWithType context_param = new PropertiesWithType();
    public java.util.Map<String, Object> parentContextMap = new java.util.HashMap<String, Object>();

    public String status= "";
    

    public static void main(String[] args){
        final Phase1_1_Incremental_Quotes_Staging Phase1_1_Incremental_Quotes_StagingClass = new Phase1_1_Incremental_Quotes_Staging();

        int exitCode = Phase1_1_Incremental_Quotes_StagingClass.runJobInTOS(args);
	        if(exitCode==0){
		        log.info("TalendJob: 'Phase1_1_Incremental_Quotes_Staging' - Done.");
	        }

        System.exit(exitCode);
    }


    public String[][] runJob(String[] args) {

        int exitCode = runJobInTOS(args);
        String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

        return bufferValue;
    }

    public boolean hastBufferOutputComponent() {
		boolean hastBufferOutput = false;
    	
        return hastBufferOutput;
    }

    public int runJobInTOS(String[] args) {
	   	// reset status
	   	status = "";
	   	
        String lastStr = "";
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--context_param")) {
                lastStr = arg;
            } else if (lastStr.equals("")) {
                evalParam(arg);
            } else {
                evalParam(lastStr + " " + arg);
                lastStr = "";
            }
        }

	        if(!"".equals(log4jLevel)){
				if("trace".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.TRACE);
				}else if("debug".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.DEBUG);
				}else if("info".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.INFO);
				}else if("warn".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.WARN);
				}else if("error".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.ERROR);
				}else if("fatal".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.FATAL);
				}else if ("off".equalsIgnoreCase(log4jLevel)){
					log.setLevel(org.apache.log4j.Level.OFF);
				}
				org.apache.log4j.Logger.getRootLogger().setLevel(log.getLevel());
    	    }
        	log.info("TalendJob: 'Phase1_1_Incremental_Quotes_Staging' - Start.");
    	
    	
    	
			if(enableLogStash) {
				java.util.Properties properties_talendJobLog = new java.util.Properties();
				properties_talendJobLog.setProperty("root.logger", "audit");
				properties_talendJobLog.setProperty("encoding", "UTF-8");
				properties_talendJobLog.setProperty("application.name", "Talend Studio");
				properties_talendJobLog.setProperty("service.name", "Talend Studio Job");
				properties_talendJobLog.setProperty("instance.name", "Talend Studio Job Instance");
				properties_talendJobLog.setProperty("propagate.appender.exceptions", "none");
				properties_talendJobLog.setProperty("log.appender", "file");
				properties_talendJobLog.setProperty("appender.file.path", "audit.json");
				properties_talendJobLog.setProperty("appender.file.maxsize", "52428800");
				properties_talendJobLog.setProperty("appender.file.maxbackup", "20");
				properties_talendJobLog.setProperty("host", "false");
				
				auditLogger_talendJobLog = org.talend.job.audit.JobEventAuditLoggerFactory.createJobAuditLogger(properties_talendJobLog);
			}
		

        if(clientHost == null) {
            clientHost = defaultClientHost;
        }

        if(pid == null || "0".equals(pid)) {
            pid = TalendString.getAsciiRandomString(6);
        }

        if (rootPid==null) {
            rootPid = pid;
        }
        if (fatherPid==null) {
            fatherPid = pid;
        }else{
            isChildJob = true;
        }

        if (portStats != null) {
            // portStats = -1; //for testing
            if (portStats < 0 || portStats > 65535) {
                // issue:10869, the portStats is invalid, so this client socket can't open
                System.err.println("The statistics socket port " + portStats + " is invalid.");
                execStat = false;
            }
        } else {
            execStat = false;
        }

        try {
            //call job/subjob with an existing context, like: --context=production. if without this parameter, there will use the default context instead.
            java.io.InputStream inContext = Phase1_1_Incremental_Quotes_Staging.class.getClassLoader().getResourceAsStream("amp/phase1_1_incremental_quotes_staging_0_1/contexts/" + contextStr + ".properties");
            if (inContext == null) {
                inContext = Phase1_1_Incremental_Quotes_Staging.class.getClassLoader().getResourceAsStream("config/contexts/" + contextStr + ".properties");
            }
            if (inContext != null) {
                //defaultProps is in order to keep the original context value
                if(context != null && context.isEmpty()) {
	                defaultProps.load(inContext);
	                context = new ContextProperties(defaultProps);
                }
                
                inContext.close();
            } else if (!isDefaultContext) {
                //print info and job continue to run, for case: context_param is not empty.
                System.err.println("Could not find the context " + contextStr);
            }

            if(!context_param.isEmpty()) {
                context.putAll(context_param);
				//set types for params from parentJobs
				for (Object key: context_param.keySet()){
					String context_key = key.toString();
					String context_type = context_param.getContextType(context_key);
					context.setContextType(context_key, context_type);

				}
            }
            class ContextProcessing {
                private void processContext_0() {
                        context.setContextType("Database_DB_Landing", "id_String");
                            context.Database_DB_Landing=(String) context.getProperty("Database_DB_Landing");
                        context.setContextType("Database_DB_Staging", "id_String");
                            context.Database_DB_Staging=(String) context.getProperty("Database_DB_Staging");
                        context.setContextType("Discovery_Service_End_Point_CRM", "id_String");
                            context.Discovery_Service_End_Point_CRM=(String) context.getProperty("Discovery_Service_End_Point_CRM");
                        context.setContextType("Host_DB_Landing", "id_String");
                            context.Host_DB_Landing=(String) context.getProperty("Host_DB_Landing");
                        context.setContextType("Host_DB_Staging", "id_String");
                            context.Host_DB_Staging=(String) context.getProperty("Host_DB_Staging");
                        context.setContextType("Mail_From", "id_String");
                            context.Mail_From=(String) context.getProperty("Mail_From");
                        context.setContextType("Mail_To", "id_String");
                            context.Mail_To=(String) context.getProperty("Mail_To");
                        context.setContextType("MergeStagingTable", "id_String");
                            context.MergeStagingTable=(String) context.getProperty("MergeStagingTable");
                        context.setContextType("OrganizeName_CRM", "id_String");
                            context.OrganizeName_CRM=(String) context.getProperty("OrganizeName_CRM");
                        context.setContextType("Password_CRM", "id_Password");
                            String pwd_Password_CRM_value = context.getProperty("Password_CRM");
                            context.Password_CRM = null;
                            if(pwd_Password_CRM_value!=null) {
                                if(context_param.containsKey("Password_CRM")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Password_CRM = pwd_Password_CRM_value;
                                } else if (!pwd_Password_CRM_value.isEmpty()) {
                                    try {
                                        context.Password_CRM = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Password_CRM_value);
                                        context.put("Password_CRM",context.Password_CRM);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("Password_DB_Landing", "id_Password");
                            String pwd_Password_DB_Landing_value = context.getProperty("Password_DB_Landing");
                            context.Password_DB_Landing = null;
                            if(pwd_Password_DB_Landing_value!=null) {
                                if(context_param.containsKey("Password_DB_Landing")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Password_DB_Landing = pwd_Password_DB_Landing_value;
                                } else if (!pwd_Password_DB_Landing_value.isEmpty()) {
                                    try {
                                        context.Password_DB_Landing = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Password_DB_Landing_value);
                                        context.put("Password_DB_Landing",context.Password_DB_Landing);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("Password_DB_Staging", "id_Password");
                            String pwd_Password_DB_Staging_value = context.getProperty("Password_DB_Staging");
                            context.Password_DB_Staging = null;
                            if(pwd_Password_DB_Staging_value!=null) {
                                if(context_param.containsKey("Password_DB_Staging")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.Password_DB_Staging = pwd_Password_DB_Staging_value;
                                } else if (!pwd_Password_DB_Staging_value.isEmpty()) {
                                    try {
                                        context.Password_DB_Staging = routines.system.PasswordEncryptUtil.decryptPassword(pwd_Password_DB_Staging_value);
                                        context.put("Password_DB_Staging",context.Password_DB_Staging);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("Port_DB_Landing", "id_String");
                            context.Port_DB_Landing=(String) context.getProperty("Port_DB_Landing");
                        context.setContextType("Port_DB_Staging", "id_String");
                            context.Port_DB_Staging=(String) context.getProperty("Port_DB_Staging");
                        context.setContextType("Schema_DB_Landing", "id_String");
                            context.Schema_DB_Landing=(String) context.getProperty("Schema_DB_Landing");
                        context.setContextType("Schema_DB_Staging", "id_String");
                            context.Schema_DB_Staging=(String) context.getProperty("Schema_DB_Staging");
                        context.setContextType("SIGMA_DB_Database", "id_String");
                            context.SIGMA_DB_Database=(String) context.getProperty("SIGMA_DB_Database");
                        context.setContextType("SIGMA_DB_Host", "id_String");
                            context.SIGMA_DB_Host=(String) context.getProperty("SIGMA_DB_Host");
                        context.setContextType("SIGMA_DB_Login", "id_String");
                            context.SIGMA_DB_Login=(String) context.getProperty("SIGMA_DB_Login");
                        context.setContextType("SIGMA_DB_Password", "id_Password");
                            String pwd_SIGMA_DB_Password_value = context.getProperty("SIGMA_DB_Password");
                            context.SIGMA_DB_Password = null;
                            if(pwd_SIGMA_DB_Password_value!=null) {
                                if(context_param.containsKey("SIGMA_DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.SIGMA_DB_Password = pwd_SIGMA_DB_Password_value;
                                } else if (!pwd_SIGMA_DB_Password_value.isEmpty()) {
                                    try {
                                        context.SIGMA_DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_SIGMA_DB_Password_value);
                                        context.put("SIGMA_DB_Password",context.SIGMA_DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("SIGMA_DB_Port", "id_String");
                            context.SIGMA_DB_Port=(String) context.getProperty("SIGMA_DB_Port");
                        context.setContextType("SIGMA_DB_Schema", "id_String");
                            context.SIGMA_DB_Schema=(String) context.getProperty("SIGMA_DB_Schema");
                        context.setContextType("SigmaTable_L", "id_String");
                            context.SigmaTable_L=(String) context.getProperty("SigmaTable_L");
                        context.setContextType("SigmaTable_S", "id_String");
                            context.SigmaTable_S=(String) context.getProperty("SigmaTable_S");
                        context.setContextType("SMTP_Host", "id_String");
                            context.SMTP_Host=(String) context.getProperty("SMTP_Host");
                        context.setContextType("SMTP_Port", "id_String");
                            context.SMTP_Port=(String) context.getProperty("SMTP_Port");
                        context.setContextType("TOM_DB_Database", "id_String");
                            context.TOM_DB_Database=(String) context.getProperty("TOM_DB_Database");
                        context.setContextType("TOM_DB_Host", "id_String");
                            context.TOM_DB_Host=(String) context.getProperty("TOM_DB_Host");
                        context.setContextType("TOM_DB_Login", "id_String");
                            context.TOM_DB_Login=(String) context.getProperty("TOM_DB_Login");
                        context.setContextType("TOM_DB_Password", "id_Password");
                            String pwd_TOM_DB_Password_value = context.getProperty("TOM_DB_Password");
                            context.TOM_DB_Password = null;
                            if(pwd_TOM_DB_Password_value!=null) {
                                if(context_param.containsKey("TOM_DB_Password")) {//no need to decrypt if it come from program argument or parent job runtime
                                    context.TOM_DB_Password = pwd_TOM_DB_Password_value;
                                } else if (!pwd_TOM_DB_Password_value.isEmpty()) {
                                    try {
                                        context.TOM_DB_Password = routines.system.PasswordEncryptUtil.decryptPassword(pwd_TOM_DB_Password_value);
                                        context.put("TOM_DB_Password",context.TOM_DB_Password);
                                    } catch (java.lang.RuntimeException e) {
                                        //do nothing
                                    }
                                }
                            }
                        context.setContextType("TOM_DB_Port", "id_String");
                            context.TOM_DB_Port=(String) context.getProperty("TOM_DB_Port");
                        context.setContextType("TOM_DB_Schema", "id_String");
                            context.TOM_DB_Schema=(String) context.getProperty("TOM_DB_Schema");
                        context.setContextType("TomTable_L", "id_String");
                            context.TomTable_L=(String) context.getProperty("TomTable_L");
                        context.setContextType("TomTable_S", "id_String");
                            context.TomTable_S=(String) context.getProperty("TomTable_S");
                        context.setContextType("Username_CRM", "id_String");
                            context.Username_CRM=(String) context.getProperty("Username_CRM");
                        context.setContextType("Username_DB_Landing", "id_String");
                            context.Username_DB_Landing=(String) context.getProperty("Username_DB_Landing");
                        context.setContextType("Username_DB_Staging", "id_String");
                            context.Username_DB_Staging=(String) context.getProperty("Username_DB_Staging");
                } 
                public void processAllContext() {
                        processContext_0();
                }
            }

            new ContextProcessing().processAllContext();
        } catch (java.io.IOException ie) {
            System.err.println("Could not load context "+contextStr);
            ie.printStackTrace();
        }

        // get context value from parent directly
        if (parentContextMap != null && !parentContextMap.isEmpty()) {if (parentContextMap.containsKey("Database_DB_Landing")) {
                context.Database_DB_Landing = (String) parentContextMap.get("Database_DB_Landing");
            }if (parentContextMap.containsKey("Database_DB_Staging")) {
                context.Database_DB_Staging = (String) parentContextMap.get("Database_DB_Staging");
            }if (parentContextMap.containsKey("Discovery_Service_End_Point_CRM")) {
                context.Discovery_Service_End_Point_CRM = (String) parentContextMap.get("Discovery_Service_End_Point_CRM");
            }if (parentContextMap.containsKey("Host_DB_Landing")) {
                context.Host_DB_Landing = (String) parentContextMap.get("Host_DB_Landing");
            }if (parentContextMap.containsKey("Host_DB_Staging")) {
                context.Host_DB_Staging = (String) parentContextMap.get("Host_DB_Staging");
            }if (parentContextMap.containsKey("Mail_From")) {
                context.Mail_From = (String) parentContextMap.get("Mail_From");
            }if (parentContextMap.containsKey("Mail_To")) {
                context.Mail_To = (String) parentContextMap.get("Mail_To");
            }if (parentContextMap.containsKey("MergeStagingTable")) {
                context.MergeStagingTable = (String) parentContextMap.get("MergeStagingTable");
            }if (parentContextMap.containsKey("OrganizeName_CRM")) {
                context.OrganizeName_CRM = (String) parentContextMap.get("OrganizeName_CRM");
            }if (parentContextMap.containsKey("Password_CRM")) {
                context.Password_CRM = (java.lang.String) parentContextMap.get("Password_CRM");
            }if (parentContextMap.containsKey("Password_DB_Landing")) {
                context.Password_DB_Landing = (java.lang.String) parentContextMap.get("Password_DB_Landing");
            }if (parentContextMap.containsKey("Password_DB_Staging")) {
                context.Password_DB_Staging = (java.lang.String) parentContextMap.get("Password_DB_Staging");
            }if (parentContextMap.containsKey("Port_DB_Landing")) {
                context.Port_DB_Landing = (String) parentContextMap.get("Port_DB_Landing");
            }if (parentContextMap.containsKey("Port_DB_Staging")) {
                context.Port_DB_Staging = (String) parentContextMap.get("Port_DB_Staging");
            }if (parentContextMap.containsKey("Schema_DB_Landing")) {
                context.Schema_DB_Landing = (String) parentContextMap.get("Schema_DB_Landing");
            }if (parentContextMap.containsKey("Schema_DB_Staging")) {
                context.Schema_DB_Staging = (String) parentContextMap.get("Schema_DB_Staging");
            }if (parentContextMap.containsKey("SIGMA_DB_Database")) {
                context.SIGMA_DB_Database = (String) parentContextMap.get("SIGMA_DB_Database");
            }if (parentContextMap.containsKey("SIGMA_DB_Host")) {
                context.SIGMA_DB_Host = (String) parentContextMap.get("SIGMA_DB_Host");
            }if (parentContextMap.containsKey("SIGMA_DB_Login")) {
                context.SIGMA_DB_Login = (String) parentContextMap.get("SIGMA_DB_Login");
            }if (parentContextMap.containsKey("SIGMA_DB_Password")) {
                context.SIGMA_DB_Password = (java.lang.String) parentContextMap.get("SIGMA_DB_Password");
            }if (parentContextMap.containsKey("SIGMA_DB_Port")) {
                context.SIGMA_DB_Port = (String) parentContextMap.get("SIGMA_DB_Port");
            }if (parentContextMap.containsKey("SIGMA_DB_Schema")) {
                context.SIGMA_DB_Schema = (String) parentContextMap.get("SIGMA_DB_Schema");
            }if (parentContextMap.containsKey("SigmaTable_L")) {
                context.SigmaTable_L = (String) parentContextMap.get("SigmaTable_L");
            }if (parentContextMap.containsKey("SigmaTable_S")) {
                context.SigmaTable_S = (String) parentContextMap.get("SigmaTable_S");
            }if (parentContextMap.containsKey("SMTP_Host")) {
                context.SMTP_Host = (String) parentContextMap.get("SMTP_Host");
            }if (parentContextMap.containsKey("SMTP_Port")) {
                context.SMTP_Port = (String) parentContextMap.get("SMTP_Port");
            }if (parentContextMap.containsKey("TOM_DB_Database")) {
                context.TOM_DB_Database = (String) parentContextMap.get("TOM_DB_Database");
            }if (parentContextMap.containsKey("TOM_DB_Host")) {
                context.TOM_DB_Host = (String) parentContextMap.get("TOM_DB_Host");
            }if (parentContextMap.containsKey("TOM_DB_Login")) {
                context.TOM_DB_Login = (String) parentContextMap.get("TOM_DB_Login");
            }if (parentContextMap.containsKey("TOM_DB_Password")) {
                context.TOM_DB_Password = (java.lang.String) parentContextMap.get("TOM_DB_Password");
            }if (parentContextMap.containsKey("TOM_DB_Port")) {
                context.TOM_DB_Port = (String) parentContextMap.get("TOM_DB_Port");
            }if (parentContextMap.containsKey("TOM_DB_Schema")) {
                context.TOM_DB_Schema = (String) parentContextMap.get("TOM_DB_Schema");
            }if (parentContextMap.containsKey("TomTable_L")) {
                context.TomTable_L = (String) parentContextMap.get("TomTable_L");
            }if (parentContextMap.containsKey("TomTable_S")) {
                context.TomTable_S = (String) parentContextMap.get("TomTable_S");
            }if (parentContextMap.containsKey("Username_CRM")) {
                context.Username_CRM = (String) parentContextMap.get("Username_CRM");
            }if (parentContextMap.containsKey("Username_DB_Landing")) {
                context.Username_DB_Landing = (String) parentContextMap.get("Username_DB_Landing");
            }if (parentContextMap.containsKey("Username_DB_Staging")) {
                context.Username_DB_Staging = (String) parentContextMap.get("Username_DB_Staging");
            }
        }

        //Resume: init the resumeUtil
        resumeEntryMethodName = ResumeUtil.getResumeEntryMethodName(resuming_checkpoint_path);
        resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
        resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName, jobName, contextStr, jobVersion);

		List<String> parametersToEncrypt = new java.util.ArrayList<String>();
			parametersToEncrypt.add("Password_CRM");
			parametersToEncrypt.add("Password_DB_Landing");
			parametersToEncrypt.add("Password_DB_Staging");
			parametersToEncrypt.add("SIGMA_DB_Password");
			parametersToEncrypt.add("TOM_DB_Password");
        //Resume: jobStart
        resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","","","",resumeUtil.convertToJsonText(context,parametersToEncrypt));

if(execStat) {
    try {
        runStat.openSocket(!isChildJob);
        runStat.setAllPID(rootPid, fatherPid, pid, jobName);
        runStat.startThreadStat(clientHost, portStats);
        runStat.updateStatOnJob(RunStat.JOBSTART, fatherNode);
    } catch (java.io.IOException ioException) {
        ioException.printStackTrace();
    }
}



	
	    java.util.concurrent.ConcurrentHashMap<Object, Object> concurrentHashMap = new java.util.concurrent.ConcurrentHashMap<Object, Object>();
	    globalMap.put("concurrentHashMap", concurrentHashMap);
	

    long startUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
    long endUsedMemory = 0;
    long end = 0;

    startTime = System.currentTimeMillis();




this.globalResumeTicket = true;//to run tPreJob

try {
errorCode = null;tPrejob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPrejob_1) {
globalMap.put("tPrejob_1_SUBPROCESS_STATE", -1);

e_tPrejob_1.printStackTrace();

}


		if(enableLogStash) {
	        talendJobLog.addJobStartMessage();
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }

this.globalResumeTicket = false;//to run others jobs

try {
errorCode = null;tJava_2Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tJava_2) {
globalMap.put("tJava_2_SUBPROCESS_STATE", -1);

e_tJava_2.printStackTrace();

}

this.globalResumeTicket = true;//to run tPostJob

try {
errorCode = null;tPostjob_1Process(globalMap);
if(!"failure".equals(status)) { status = "end"; }
}catch (TalendException e_tPostjob_1) {
globalMap.put("tPostjob_1_SUBPROCESS_STATE", -1);

e_tPostjob_1.printStackTrace();

}



        end = System.currentTimeMillis();

        if (watch) {
            System.out.println((end-startTime)+" milliseconds");
        }

        endUsedMemory = Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory();
        if (false) {
            System.out.println((endUsedMemory - startUsedMemory) + " bytes memory increase when running : Phase1_1_Incremental_Quotes_Staging");
        }
		if(enableLogStash) {
	        talendJobLog.addJobEndMessage(startTime, end, status);
	        try {
	            talendJobLogProcess(globalMap);
	        } catch (java.lang.Exception e) {
	            e.printStackTrace();
	        }
        }



if (execStat) {
    runStat.updateStatOnJob(RunStat.JOBEND, fatherNode);
    runStat.stopThreadStat();
}
    int returnCode = 0;
    if(errorCode == null) {
         returnCode = status != null && status.equals("failure") ? 1 : 0;
    } else {
         returnCode = errorCode.intValue();
    }
    resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher, Thread.currentThread().getId() + "", "","" + returnCode,"","","");

    return returnCode;

  }

    // only for OSGi env
    public void destroy() {
    closeSqlDbConnections();


    }



    private void closeSqlDbConnections() {
        try {
            Object obj_conn;
            obj_conn = globalMap.remove("conn_tDBConnection_1");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_2");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_3");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
            obj_conn = globalMap.remove("conn_tDBConnection_4");
            if (null != obj_conn) {
                ((java.sql.Connection) obj_conn).close();
            }
        } catch (java.lang.Exception e) {
        }
    }











    private java.util.Map<String, Object> getSharedConnections4REST() {
        java.util.Map<String, Object> connections = new java.util.HashMap<String, Object>();
            connections.put("conn_tDBConnection_1", globalMap.get("conn_tDBConnection_1"));
            connections.put("conn_tDBConnection_2", globalMap.get("conn_tDBConnection_2"));
            connections.put("conn_tDBConnection_3", globalMap.get("conn_tDBConnection_3"));
            connections.put("conn_tDBConnection_4", globalMap.get("conn_tDBConnection_4"));







        return connections;
    }

    private void evalParam(String arg) {
        if (arg.startsWith("--resuming_logs_dir_path")) {
            resuming_logs_dir_path = arg.substring(25);
        } else if (arg.startsWith("--resuming_checkpoint_path")) {
            resuming_checkpoint_path = arg.substring(27);
        } else if (arg.startsWith("--parent_part_launcher")) {
            parent_part_launcher = arg.substring(23);
        } else if (arg.startsWith("--watch")) {
            watch = true;
        } else if (arg.startsWith("--stat_port=")) {
            String portStatsStr = arg.substring(12);
            if (portStatsStr != null && !portStatsStr.equals("null")) {
                portStats = Integer.parseInt(portStatsStr);
            }
        } else if (arg.startsWith("--trace_port=")) {
            portTraces = Integer.parseInt(arg.substring(13));
        } else if (arg.startsWith("--client_host=")) {
            clientHost = arg.substring(14);
        } else if (arg.startsWith("--context=")) {
            contextStr = arg.substring(10);
            isDefaultContext = false;
        } else if (arg.startsWith("--father_pid=")) {
            fatherPid = arg.substring(13);
        } else if (arg.startsWith("--root_pid=")) {
            rootPid = arg.substring(11);
        } else if (arg.startsWith("--father_node=")) {
            fatherNode = arg.substring(14);
        } else if (arg.startsWith("--pid=")) {
            pid = arg.substring(6);
        } else if (arg.startsWith("--context_type")) {
            String keyValue = arg.substring(15);
			int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.setContextType(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.setContextType(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }

            }

		} else if (arg.startsWith("--context_param")) {
            String keyValue = arg.substring(16);
            int index = -1;
            if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
                if (fatherPid==null) {
                    context_param.put(keyValue.substring(0, index), replaceEscapeChars(keyValue.substring(index + 1)));
                } else { // the subjob won't escape the especial chars
                    context_param.put(keyValue.substring(0, index), keyValue.substring(index + 1) );
                }
            }
        } else if (arg.startsWith("--log4jLevel=")) {
            log4jLevel = arg.substring(13);
		} else if (arg.startsWith("--monitoring=")) {//for trunjob call
			enableLogStash = "true".equalsIgnoreCase(arg.substring(13));
		}
		
		if(!enableLogStash) {
			enableLogStash = "true".equalsIgnoreCase(System.getProperty("monitoring"));
		}
    }
    
    private static final String NULL_VALUE_EXPRESSION_IN_COMMAND_STRING_FOR_CHILD_JOB_ONLY = "<TALEND_NULL>";

    private final String[][] escapeChars = {
        {"\\\\","\\"},{"\\n","\n"},{"\\'","\'"},{"\\r","\r"},
        {"\\f","\f"},{"\\b","\b"},{"\\t","\t"}
        };
    private String replaceEscapeChars (String keyValue) {

		if (keyValue == null || ("").equals(keyValue.trim())) {
			return keyValue;
		}

		StringBuilder result = new StringBuilder();
		int currIndex = 0;
		while (currIndex < keyValue.length()) {
			int index = -1;
			// judege if the left string includes escape chars
			for (String[] strArray : escapeChars) {
				index = keyValue.indexOf(strArray[0],currIndex);
				if (index>=0) {

					result.append(keyValue.substring(currIndex, index + strArray[0].length()).replace(strArray[0], strArray[1]));
					currIndex = index + strArray[0].length();
					break;
				}
			}
			// if the left string doesn't include escape chars, append the left into the result
			if (index < 0) {
				result.append(keyValue.substring(currIndex));
				currIndex = currIndex + keyValue.length();
			}
		}

		return result.toString();
    }

    public Integer getErrorCode() {
        return errorCode;
    }


    public String getStatus() {
        return status;
    }

    ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 *     304696 characters generated by Talend Cloud Data Management Platform 
 *     on the 19 March, 2020 12:47:21 PM IST
 ************************************************************************************************/